﻿using SomerenModel;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenDAL
{
    public class CashRegisterDao: BaseDao
    {
        //update stock
        public void UpdateStock(Drink drink)
        {
            string query = $"UPDATE Drink Set stock = @stock  WHERE DrinkID = @DrinkID";

            SqlParameter[] sqlParameters =
            {
                new SqlParameter("stock", drink.stock),
                 new SqlParameter("DrinkID", drink.DrinkID)
            };

            ExecuteEditQuery(query, sqlParameters);
            
        }

        // record purchase
        public void DrinkSale(Drink drink,Student student)
        {

            string query = $"INSERT INTO Drink_Orders (StudentId, DrinkId, DateTime)" + $"values(@StudentId, @DrinkId, @DateTime); " +
                $"SELECT SCOPE_IDENTITY()";

            SqlParameter[] sqlParameters =
            {
                 new SqlParameter("StudentId", student.Number),
                 new SqlParameter("DrinkId", drink.DrinkID),
                 new SqlParameter("DateTime", DateTime.Now)

            };
            ExecuteEditQuery(query, sqlParameters);

        }
    }
}
