﻿using SomerenModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenDAL
{
    public class TeacherDAO : BaseDao
    {
        public List<Teacher> GetAllTeacher()
        {
            string query = "SELECT TeacherID, RoomID, firstname, lastname, supervisor FROM [Teacher]";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }

        private List<Teacher> ReadTables(DataTable dataTable)
        {
            List<Teacher> teachers = new List<Teacher>();

            foreach (DataRow dr in dataTable.Rows)
            {
                Teacher teacher = new Teacher()
                {
                    TeacherID = (int)dr["TeacherID"],
                    RoomID = (int)(dr["RoomID"]),
                    firstname = (string)(dr["firstname"]),
                    lastname = (string)(dr["lastname"]),
                    supervisor = (bool)(dr["supervisor"])
                };
                teachers.Add(teacher);
            }
            return teachers;
        }
    }
}
