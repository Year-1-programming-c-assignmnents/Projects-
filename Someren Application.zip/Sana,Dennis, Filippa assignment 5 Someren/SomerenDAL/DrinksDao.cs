﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using SomerenModel;
using System.Collections.Generic;

namespace SomerenDAL
{
    public class DrinksDao : BaseDao
    {
        public List<Drink> GetAllDrinks()
        {
            string query = "SELECT DrinkID, stock, Names, Sales_price, Drink_type FROM [Drink] WHERE stock > 1 and Sales_price > 1 ORDER BY stock, Sales_price"; 
            //+
            //$" SELECT Names FROM [Drink] LIKE NOT '%Water%' AND Names FROM [Drink] LIKE NOT '%Orangeade%' AND Names FROM [Drink] LIKE NOT '%Cherry juice%' ORDER " +
            //$"By stock DESC, price DESC ";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }
        public void InsertDrink(Drink drink)
        {
            string query = $"INSERT INTO Drink (stock,Names,Sales_price,Drink_type )" +
                $"values('{drink.stock}', '{drink.Names}', '{drink.Sales_price}', '{drink.Drink_type}')";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
        }
        public void RemoveDrink(Drink drink)
        {
            string query = $"DELETE FROM Drink WHERE DrinkID = {drink.DrinkID}";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
        }
        public void ChangeDrink(Drink drink)
        {
            string query = $"update Drink Set stock = '{drink.stock}', Names = '{drink.Names}'," +
                $"Sales_price = '{drink.Sales_price}', Drink_type = '{drink.Drink_type}'  WHERE DrinkID = {drink.DrinkID}";

            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);

        }

        private List<Drink> ReadTables(DataTable dataTable)
        {
            List<Drink> drinks = new List<Drink>();

            foreach (DataRow dr in dataTable.Rows)
            {
                Drink drink = new Drink()
                {
                    DrinkID = (int)dr["DrinkID"],
                    stock = (int)dr["stock"],
                    Names = (string)(dr["Names"].ToString()),
                    Sales_price = (int)dr["Sales_price"],
                    Drink_type = (string)(dr["Drink_type"])
                };
                drinks.Add(drink);
            }
            return drinks;
        }
    }
}
