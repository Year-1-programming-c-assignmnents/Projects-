﻿using SomerenModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenDAL
{
    public class RevenueReportDao : BaseDao
    {
        public List<Drink_Order> GetDrink_Order_By_Dates(DateTime startdate, DateTime enddate)
        {
            string query = "SELECT Order_nr, StudentId, [Drink_Orders].DrinkId, Drink.Sales_price, DateTime FROM [Drink_Orders] INNER JOIN [Drink] ON [Drink_Orders].DrinkId = [Drink].DrinkID WHERE DateTime BETWEEN @strdate AND @nddate";
            SqlParameter[] sqlParameters =
            {
                new SqlParameter("@strdate", startdate),
                 new SqlParameter("@nddate", enddate)
            };
           return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }

        private List<Drink_Order> ReadTables(DataTable dataTable)
        {
            List<Drink_Order> drinkorders = new List<Drink_Order>();

            foreach (DataRow dr in dataTable.Rows)
            {
                Drink_Order drinkorder = new Drink_Order()
                {
                    StudentId = (int)dr["StudentId"],
                    DrinkId = (int)(dr["DrinkId"]),
                    Price = (int)(dr["Sales_price"]),
                    DATETIME = (DateTime)(dr["DateTime"])
                };
                drinkorders.Add(drinkorder);
            }
            return drinkorders;
        }
    }
}
