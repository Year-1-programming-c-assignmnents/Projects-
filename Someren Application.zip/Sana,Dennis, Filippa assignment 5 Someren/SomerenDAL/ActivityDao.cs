﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Threading.Tasks;
using SomerenModel;

namespace SomerenDAL
{
    public class ActivityDao : BaseDao
    {
        public List<Activity> GetAllActivity()
        {
            string query = "SELECT ActivityID, Name, StartDateTime, EndDateTime FROM [Activity]";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }
        private List<Activity> ReadTables(DataTable dataTable)
        {
            List<Activity> activitys = new List<Activity>();

            foreach (DataRow actvities in dataTable.Rows)
            {
                Activity Actvities = new Activity()
                {
                    ActivityID = (int)actvities["ActivityID"],
                    Name = (string)actvities["Name"],
                    StartDateTime = (DateTime)actvities["StartDateTime"],
                    EndDateTime = (DateTime)(actvities["EndDateTime"])
                };
                activitys.Add(Actvities);
            }
            return activitys;
        }
        public void InsertActivity(Activity activity)
        {
            string query = $"INSERT INTO Activity (Name,StartDateTime,EndDateTime )" +
                $"values('{activity.Name}', '{activity.StartDateTime}', '{activity.EndDateTime}')" +
                $"SELECT SCOPE_IDENTITY()";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
        }
        public void ChangeActivity(Activity activity)
        {
            string query = $"update Activity Set Name = '{activity.Name}', StartDateTime = '{activity.StartDateTime}'," +
                $"EndDateTime = '{activity.EndDateTime}',  WHERE ActivityID = {activity.ActivityID}";

            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
        }
        public void RemoveActivity(Activity activity)
        {
            string query = $"DELETE FROM Activity WHERE ActivityID = {activity.ActivityID}";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
        }
    }
}
