﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SomerenModel;

namespace SomerenDAL
{
    public class SupervisorDao : BaseDao
    {
        public List<Supervisor> GetAllSupervisorActivities()
        {
            string query = "SELECT Supervisor.TeacherID,Teacher.firstname,Teacher.lastname,Supervisor.ActivityID,Activity.Name FROM Supervisor JOIN Activity ON Supervisor.ActivityID = Activity.ActivityID JOIN Teacher ON Supervisor.TeacherID = Teacher.TeacherID;";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }

        private List<Supervisor> ReadTables(DataTable dataTable)
        {
            List<Supervisor> supervisors = new List<Supervisor>();

            foreach (DataRow dr in dataTable.Rows)
            {
                Supervisor supervisor = new Supervisor()
                {
                    teacherId = (int)dr["TeacherID"],
                    teacherFirstName = (string)(dr["firstname"].ToString()),
                    teacherLastName = (string)(dr["lastname"].ToString()),
                    activityId = (int)dr["ActivityID"],
                    activityName = (string)(dr["Name"].ToString())
                };
                supervisors.Add(supervisor);
            }
            return supervisors;
        }

        public void AddSupervisor(Teacher teacher, Activity activity)
        {
            string query = $"INSERT INTO Supervisor (ActivityID, TeacherID)" + $"values(@ActivityID, @TeacherID); " +
                $"SELECT SCOPE_IDENTITY()";

            SqlParameter[] sqlParameters =
            {
                 new SqlParameter("ActivityID", activity.ActivityID),
                 new SqlParameter("TeacherID", teacher.TeacherID ),

            };

            ExecuteEditQuery(query, sqlParameters);

        }

        public void Remove(Supervisor supervisor)
        {
            string query = $"DELETE FROM Supervisor WHERE TeacherID = @Id";

            SqlParameter[] sqlParameters =
            {
                 new SqlParameter("Id", supervisor.teacherId),
            };

            ExecuteEditQuery(query, sqlParameters);
        }
    }
}
