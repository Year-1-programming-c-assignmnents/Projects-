﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using SomerenModel;

namespace SomerenDAL
{
    public class UsersDao : BaseDao
    {

        public Users UsersLogin(string UserName, string UserPassword )
        {
            SqlCommand cmd = new SqlCommand("select UserID, UserName, UserPassword, UserStatus from Users WHERE [UserPassword] = @pass and [UserName] = @name ", conn);
            cmd.Parameters.AddWithValue("@pass", UserPassword);
            cmd.Parameters.AddWithValue("@name", UserName);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            Users users = UserRead(reader);
            conn.Close();
            reader.Close();
            if (users == null)
            {
                return null;
            }

            return users;
        }
        public List<Users> UsersList()
        {
            Users users = new Users();
            string query = "SELECT UserName, UserPassword, UserStatus , UserID FROM [Users]";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadUsers(ExecuteSelectQuery(query, sqlParameters));
        }
        public Users UserRead(SqlDataReader reader)
        {
            Users users = new Users
            {
                //UserID = (int)reader["UserID"],
                UserName = (string)reader["UserName"],
                UserPassword = (string)reader["UserPassword"],
                //UserStatus = (string)reader["UserStatus"],
            };
            return users;
        }
        public void AddToListUsers(Users users)
        {
            string query = $"INSERT INTO [Users] (UserName, UserPassword) VALUES ('{users.UserName}','{users.UserPassword}')";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
        }
        public List<Users> ReadUsers(DataTable dataTable)
        {
            List<Users> users = new List<Users>();
            foreach (DataRow row in dataTable.Rows)
            {
                Users user = new Users
                {
                    UserName = row["UserName"].ToString(),
                    UserPassword = row["UserPassword"].ToString(),
                    secretQuestion = row["SecretQuestion"].ToString(),
                    secretPassword = row["SecretAnswer"].ToString(),
                };
                users.Add(user);
            }
            return users;
        }

        public void ForgotPassword(string userName, string secretAnswer)
        {
            string query = "SELECT UserName, SecretAnswer FROM Users WHERE SecretAnswer = @SecretAnswer AND UserName = @UserName";
            SqlParameter[] sqlParameters =
            {
                 new SqlParameter("SecretAnswer", secretAnswer),
                 new SqlParameter("UserName", userName )
            };

            ExecuteEditQuery(query, sqlParameters);  
        }

        public void NewPassword(string userName, string newPassword)
        {
            string query = "UPDATE Users set UserPassword = @UserPassword WHERE UserName = @UserName";
            SqlParameter[] sqlParameters =
            {
                 new SqlParameter("UserPassword", newPassword),
                 new SqlParameter("UserName", userName )
            };

            ExecuteEditQuery(query, sqlParameters);
        }
    }
}
