﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SomerenModel;

namespace SomerenDAL
{
    public class ActivityParticipantsDao : BaseDao
    {
        public List<ActivityParticipants> GetAllParticipantsActivities()
        {
            string query = "SELECT Participants.StudentID,Students.FirstName,Students.LastName,Participants.ActivityID,Activity.Name FROM Participants JOIN Activity ON Participants.ActivityID = Activity.ActivityID JOIN Students ON Participants.StudentID = Students.StudentID;";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }
        private List<ActivityParticipants> ReadTables(DataTable dataTable)
        {
            List<ActivityParticipants> participants = new List<ActivityParticipants>();

            foreach (DataRow dr in dataTable.Rows)
            {
                ActivityParticipants participant = new ActivityParticipants()
                {
                    studentId = (int)dr["StudentID"],
                    studentFirstName = (string)(dr["FirstName"].ToString()),
                    studentLastName = (string)(dr["LastName"].ToString()),
                    activityId = (int)dr["ActivityID"],
                    activityName = (string)(dr["Name"].ToString())
                };
                participants.Add(participant);
            }
            return participants;
        }
        public void AddParticipant(Student student, Activity activity)
        {
            string query = $"INSERT INTO Participants (ActivityID, StudentID)" + $"values(@ActivityID, @StudentID); " +
                $"SELECT SCOPE_IDENTITY()";

            SqlParameter[] sqlParameters =
            {
                 new SqlParameter("ActivityID", activity.ActivityID),
                 new SqlParameter("StudentID", student.StudentID),

            };

            ExecuteEditQuery(query, sqlParameters);
        }
        public void RemoveParticipant(ActivityParticipants activityParticipants)
        {
            string query = $"DELETE FROM Participants WHERE StudentID = @Id";

            SqlParameter[] sqlParameters =
            {
                 new SqlParameter("Id", activityParticipants.studentId),
            };

            ExecuteEditQuery(query, sqlParameters);
        }
    }
}
