﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SomerenDAL;
using SomerenModel;

namespace SomerenLogic
{
    public class ActivityParticipantsService
    {
        ActivityParticipantsDao activityParticipantsDao;
        public ActivityParticipantsService()
        {
            activityParticipantsDao = new ActivityParticipantsDao();
        }
        public List<ActivityParticipants> GetParticipant()
        {
            List<ActivityParticipants> participant = activityParticipantsDao.GetAllParticipantsActivities();
            return participant;
        }
        public void AddParticipants(Student student, Activity activity)
        {
            activityParticipantsDao.AddParticipant(student, activity);
        }

        public void RemoveParticipants(ActivityParticipants participants)
        {
            activityParticipantsDao.RemoveParticipant(participants);
        }
    }
}
