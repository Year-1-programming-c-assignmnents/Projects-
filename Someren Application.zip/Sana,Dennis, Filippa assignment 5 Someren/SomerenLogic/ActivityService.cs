﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SomerenDAL;
using SomerenModel;

namespace SomerenLogic
{
    public class ActivityService
    {

        ActivityDao Activitydb;

        public ActivityService()
        {
            Activitydb = new ActivityDao();
        }

        public List<Activity> GetActivity()
        {
            List<Activity> Activities = Activitydb.GetAllActivity();
            return Activities;
        }
        public void InsertActivity(Activity activity)
        {
            Activitydb.InsertActivity(activity);
        }
        public void ChangeActivity(Activity activity)
        {
            Activitydb.ChangeActivity(activity);
        }
        public void RemoveActivity(Activity activity)
        {
            Activitydb.RemoveActivity(activity);
        }

    }
}
