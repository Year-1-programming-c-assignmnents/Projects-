﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SomerenDAL;
using SomerenModel;


namespace SomerenLogic
{
    public class DrinksService
    {
        DrinksDao drinksdb;
       
        public DrinksService()
        {
            drinksdb = new DrinksDao();
        }

        public List<Drink> GetDrinks()
        {
            List<Drink> drinks = drinksdb.GetAllDrinks();
            return drinks;
        }
        public void InsertDrink(Drink drink)
        {
            drinksdb.InsertDrink(drink);
        }
        public void RemoveDrink(Drink drink)
        {
            drinksdb.RemoveDrink(drink);
        }
        public void ChangeDrink(Drink drink)
        {
            drinksdb.ChangeDrink(drink);
        }
    }
}
