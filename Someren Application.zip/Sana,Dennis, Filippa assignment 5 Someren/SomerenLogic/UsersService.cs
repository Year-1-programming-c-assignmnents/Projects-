﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SomerenDAL;
using SomerenModel;


namespace SomerenLogic
{
    public class UsersService
    {
        UsersDao usersdb;
        public UsersService()
        {
            usersdb = new UsersDao();

        }
        public Users UsersLogin(string UserName, string UserPassword)
        {
            return usersdb.UsersLogin(UserName, UserPassword);
        }
        public List<Users> StartUser()
        {
            List<Users> users = usersdb.UsersList();
            return users;
        }
        public void AddToListUsers(Users user)
        {
            usersdb.AddToListUsers(user);
        }
        public void ForgotPassword(string userName,string secretAnswer)
        {
            usersdb.ForgotPassword(userName, secretAnswer);
        }
        public void NewPassword(string userName, string newPassword)
        {
            usersdb.NewPassword(userName, newPassword);
        }
    }
}
