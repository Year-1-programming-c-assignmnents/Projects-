﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SomerenDAL;
using SomerenModel;

namespace SomerenLogic
{
    public class SupervisorService
    {
        SupervisorDao supervisorDao;

        public SupervisorService()
        {
            supervisorDao = new SupervisorDao();
        }
        public List<Supervisor> GetStupervisors()
        {
            List<Supervisor> supervisor = supervisorDao.GetAllSupervisorActivities();
            return supervisor;
        }

        public void AddSupervisors(Teacher teacher, Activity activity)
        {
            supervisorDao.AddSupervisor(teacher, activity);
        }

        public void Remove(Supervisor supervisor)
        {
            supervisorDao.Remove(supervisor);
        }

    }
}
