﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SomerenDAL;
using SomerenModel;

namespace SomerenLogic
{
    public class ReportRevenueService
    {
        RevenueReportDao revenuereportdb;
        List<Drink_Order> drink_Orders;
        public ReportRevenueService(DateTime startdate, DateTime enddate)
        {
            revenuereportdb = new RevenueReportDao();
            drink_Orders = revenuereportdb.GetDrink_Order_By_Dates(startdate, enddate);
        }
        public int Sales { get { return drink_Orders.Count; } }
        public int TurnOver { 
            get 
            {
                int totalprice = 0;
                foreach(Drink_Order dr in drink_Orders)
                {
                    totalprice += dr.Price;
                }
                return totalprice;
            } 
        }
        public int NumberOfCustomers { 
            get 
            {
                List<int> customerlist = new List<int>(); 
                foreach(Drink_Order dr in drink_Orders)
                {
                    if(!customerlist.Contains(dr.StudentId))
                    {
                        customerlist.Add(dr.StudentId);
                    }
                }
                return customerlist.Count;
            }  
        }
    }
}

