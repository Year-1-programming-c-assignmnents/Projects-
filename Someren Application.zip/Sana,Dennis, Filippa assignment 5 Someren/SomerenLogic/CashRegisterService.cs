﻿using SomerenDAL;
using SomerenModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenLogic
{
    public class CashRegisterService
    {
        CashRegisterDao cashRegister;
        public CashRegisterService()
        {
            cashRegister = new CashRegisterDao();
           
        }
        public void UpdateStock(Drink drink)
        {
            cashRegister.UpdateStock(drink);
        }
        public void DrinkSale(Drink drink,Student student )
        {
            cashRegister.DrinkSale(drink,student);
        }
    }
}
