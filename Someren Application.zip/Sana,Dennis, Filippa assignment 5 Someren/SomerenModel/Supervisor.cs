﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public class Supervisor
    {
        public int teacherId;
        public string teacherFirstName;
        public string teacherLastName;
        public string TeacherFullName { get { return $"{teacherFirstName} {teacherLastName}"; } }
        public int activityId;
       public string activityName;
    }
}
