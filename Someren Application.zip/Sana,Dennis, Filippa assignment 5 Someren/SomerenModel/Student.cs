﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public class Student
    { 
        public string Names { get; set; }
        public string LastName { get; set; }
        public string FullName { get { return $"{Names} {LastName}"; } }
        

        public int Number { get; set; } // StudentNumber, e.g. 474791
        public DateTime BirthDate { get; set; }
        public SqlDbType StudentID { get; set; }

        public override string ToString()
        {
            return $"{Number} {FullName}";
        }
    }
}
