﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public class Room
    {
        public int Number { get; set; } // RoomNumber, e.g. 206
        public bool Type { get; set; } // student = false, teacher = true
        private int capacity;// number of beds, either 4,6,8,12 or 16

        public int Capacity
        {
            get { return capacity; }
            set
            {
                if (value == 4 || value == 6 || value == 8 || value == 12 || value == 16)
                {
                    capacity = value;     
                }
                else
                {
                    throw new Exception($"Invalid capacity {capacity}");
                }
            }
        }
        public override string ToString()
        {
            return $"{Number} {Capacity} {Type}";
        }

    }
}
