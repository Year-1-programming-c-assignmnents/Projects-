﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public class Drink
    {
        public int DrinkID { get; set; }
        public int stock { get; set; }
        public string Names { get; set; }
        public int Sales_price { get; set; }
        public string Drink_type { get; set; }

        public override string ToString()
        {
            return $"{DrinkID}  {Names}";
        }
    }
}
