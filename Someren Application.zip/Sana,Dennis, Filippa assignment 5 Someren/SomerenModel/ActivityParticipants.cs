﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public class ActivityParticipants
    {
        public int studentId;
        public string studentFirstName;
        public string studentLastName;
        public string StudentFullName { get { return $"{studentFirstName} {studentLastName}"; } }
        public int activityId;
        public string activityName;
    }
}
