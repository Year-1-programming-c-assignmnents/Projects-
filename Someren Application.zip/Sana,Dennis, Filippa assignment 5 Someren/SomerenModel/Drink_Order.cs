﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public class Drink_Order
    {
        public int ID;
        public int StudentId { get; set; }
        public int DrinkId { get; set; }
        public int Id { get { return ID; } }
        public int Price { get; set; }
        public DateTime DATETIME { get; set; }

        public Drink_Order()
        {
            
        }
        public Drink_Order(Student student, Drink drink)
        {
            this.StudentId = student.Number;
            this.DrinkId = drink.DrinkID;
        }
        public Drink_Order(int id, int drinkid, int studentid, DateTime dateTime)
        {
            this.ID = id;
            this.StudentId = studentid;
            this.DrinkId = drinkid;
            this.DATETIME = dateTime;
        }
        public Drink_Order(int id, int drinkid, int studentid, DateTime dateTime, int price)
        {
            this.ID = id;
            this.StudentId = studentid;
            this.DrinkId = drinkid;
            this.DATETIME = dateTime;
            this.Price = price;
        }
    }
}
