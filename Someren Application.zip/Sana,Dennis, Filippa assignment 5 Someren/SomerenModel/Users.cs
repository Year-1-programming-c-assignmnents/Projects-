﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
   public class Users
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string UserPassword { get; set; }
        public string UserStatus { get; set; }
        public string secretQuestion { get; set; }
        public string secretPassword { get; set; }

        public override string ToString()
        {
            return $"{UserID}  {UserName} {UserPassword} {UserStatus}";
        }
        public Users(int UserID, string UserName, string UserPassword, string UserStatus)
        {
            this.UserID = UserID;
            this.UserName = UserName;
            this.UserPassword = UserPassword;
            this.UserStatus = UserStatus;

        }
        public Users()
        {

        }
    }
}
