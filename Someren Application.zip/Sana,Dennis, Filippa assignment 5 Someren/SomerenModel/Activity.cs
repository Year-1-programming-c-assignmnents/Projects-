﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public class Activity
    {
        public int ActivityID { get; set; }
        public string Name { get; set; }
        public DateTime StartDateTime { get; set; }
        public DateTime EndDateTime { get; set; }
        public override string ToString()
        {
            return $"{ActivityID}  {Name} {StartDateTime} {EndDateTime}";
        }
        //public Activity(int ActivityID, string Name, DateTime StartDateTime, DateTime EndDateTime)
        //{
        //    this.ActivityID = ActivityID;
        //    this.Name = Name;
        //    this.StartDateTime = StartDateTime;
        //    this.EndDateTime = EndDateTime;

        //}
        //public Activity()
        //{

        //}
    }
}
