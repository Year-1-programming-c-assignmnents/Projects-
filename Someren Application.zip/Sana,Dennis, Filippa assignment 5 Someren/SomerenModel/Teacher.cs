﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public class Teacher
    {
        public int TeacherID { get; set; }
        public int RoomID { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string FullName { get { return $"{firstname} {lastname}"; } }
        public bool supervisor { get; set; }

        public override string ToString()
        {
            return $"{TeacherID} {RoomID} {FullName} {supervisor}";
        }

    }
}
