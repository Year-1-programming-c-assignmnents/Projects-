﻿
namespace SomerenUI
{
    partial class SignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblPassWord = new System.Windows.Forms.Label();
            this.lblRegistrationKey = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtPassWord = new System.Windows.Forms.TextBox();
            this.txtRegistrationKey = new System.Windows.Forms.TextBox();
            this.btnCreateAccount = new System.Windows.Forms.Button();
            this.btnSignUpBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Location = new System.Drawing.Point(149, 76);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(73, 17);
            this.lblUsername.TabIndex = 0;
            this.lblUsername.Text = "Username";
            // 
            // lblPassWord
            // 
            this.lblPassWord.AutoSize = true;
            this.lblPassWord.Location = new System.Drawing.Point(149, 131);
            this.lblPassWord.Name = "lblPassWord";
            this.lblPassWord.Size = new System.Drawing.Size(69, 17);
            this.lblPassWord.TabIndex = 1;
            this.lblPassWord.Text = "Password";
            // 
            // lblRegistrationKey
            // 
            this.lblRegistrationKey.AutoSize = true;
            this.lblRegistrationKey.Location = new System.Drawing.Point(149, 186);
            this.lblRegistrationKey.Name = "lblRegistrationKey";
            this.lblRegistrationKey.Size = new System.Drawing.Size(112, 17);
            this.lblRegistrationKey.TabIndex = 2;
            this.lblRegistrationKey.Text = "Registration Key";
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(267, 73);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(140, 22);
            this.txtUsername.TabIndex = 3;
            // 
            // txtPassWord
            // 
            this.txtPassWord.Location = new System.Drawing.Point(267, 128);
            this.txtPassWord.Name = "txtPassWord";
            this.txtPassWord.Size = new System.Drawing.Size(140, 22);
            this.txtPassWord.TabIndex = 4;
            // 
            // txtRegistrationKey
            // 
            this.txtRegistrationKey.Location = new System.Drawing.Point(267, 183);
            this.txtRegistrationKey.Name = "txtRegistrationKey";
            this.txtRegistrationKey.Size = new System.Drawing.Size(140, 22);
            this.txtRegistrationKey.TabIndex = 5;
            // 
            // btnCreateAccount
            // 
            this.btnCreateAccount.Location = new System.Drawing.Point(271, 250);
            this.btnCreateAccount.Name = "btnCreateAccount";
            this.btnCreateAccount.Size = new System.Drawing.Size(136, 39);
            this.btnCreateAccount.TabIndex = 6;
            this.btnCreateAccount.Text = "Create Account";
            this.btnCreateAccount.UseVisualStyleBackColor = true;
            this.btnCreateAccount.Click += new System.EventHandler(this.btnCreateAccount_Click);
            // 
            // btnSignUpBack
            // 
            this.btnSignUpBack.Location = new System.Drawing.Point(24, 294);
            this.btnSignUpBack.Name = "btnSignUpBack";
            this.btnSignUpBack.Size = new System.Drawing.Size(75, 26);
            this.btnSignUpBack.TabIndex = 17;
            this.btnSignUpBack.Text = "Back";
            this.btnSignUpBack.UseVisualStyleBackColor = true;
            this.btnSignUpBack.Click += new System.EventHandler(this.btnSignUpBack_Click);
            // 
            // SignUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(688, 343);
            this.Controls.Add(this.btnSignUpBack);
            this.Controls.Add(this.btnCreateAccount);
            this.Controls.Add(this.txtRegistrationKey);
            this.Controls.Add(this.txtPassWord);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.lblRegistrationKey);
            this.Controls.Add(this.lblPassWord);
            this.Controls.Add(this.lblUsername);
            this.Name = "SignUp";
            this.Text = "SignUp";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label lblPassWord;
        private System.Windows.Forms.Label lblRegistrationKey;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtPassWord;
        private System.Windows.Forms.TextBox txtRegistrationKey;
        private System.Windows.Forms.Button btnCreateAccount;
        private System.Windows.Forms.Button btnSignUpBack;
    }
}