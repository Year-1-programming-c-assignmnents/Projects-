﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SomerenModel;
using SomerenLogic;


namespace SomerenUI
{
    public partial class Login : Form
    {
        
        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtPasword.Text != "" && txtUsernme.Text!= "")
            {
                UsersService usersService = new UsersService();
                Users users = usersService.UsersLogin(txtUsernme.Text, txtPasword.Text);
                if (users!= null)
                {
                    SomerenUI someren = new SomerenUI();
                    this.Hide();
                    someren.Show();
                }
            }
            else
            {
                MessageBox.Show("Please enter the username and password!");
            }

        } 
        private void btnSignIn_Click(object sender, EventArgs e)
        {
            this.Hide();
            SignUp sign = new SignUp();
            sign.ShowDialog();
        }

        private void lLForgotPassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            ForgotPassword forgotPassword = new ForgotPassword ();
            forgotPassword.ShowDialog();
        }
    }

    //class LogInForm
    //{
    //}
}
