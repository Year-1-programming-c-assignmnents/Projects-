﻿using SomerenLogic;
using SomerenModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SomerenUI
{
    public partial class ForgotPassword : Form
    {
        UsersService usersService;
        public ForgotPassword()
        {
            InitializeComponent();
            usersService = new UsersService();
            EnteredInfo();
        }
        private void EnteredInfo()
        {
            txtNewPassword.Enabled = false;
            btnCheck.Enabled = false;
            btnSubmit.Enabled = false;
           
        }
        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
            CheckEnteredInfo();
        }

        private void txtQuestionAns_TextChanged(object sender, EventArgs e)
        {
            CheckEnteredInfo();
        }
        private void CheckEnteredInfo()
        {
            if (txtUsername.Text != "" && txtQuestionAns.Text != "")
            {
                btnCheck.Enabled = true;
            }
            if (txtNewPassword.Text != "")
            {
                btnSubmit.Enabled = true;
            }
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            try
            {
                usersService.ForgotPassword(txtUsername.Text, txtQuestionAns.Text);
                txtNewPassword.Enabled = true;
            }
            catch (Exception)
            {
                MessageBox.Show("Incorrect Username or secret answer");
            }
        }

        private void txtNewPassword_TextChanged(object sender, EventArgs e)
        {
            CheckEnteredInfo();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string UserName = txtUsername.Text;
            string newPassword = txtNewPassword.Text;
            usersService.NewPassword(UserName, newPassword);
            ShowLoginForm();
        }

        void ShowLoginForm()
        {
            this.Hide();
            Login login = new Login();
            login.ShowDialog();
        }
        private void btnFPBack_Click(object sender, EventArgs e)
        {
            ShowLoginForm();
        }
    }
}
