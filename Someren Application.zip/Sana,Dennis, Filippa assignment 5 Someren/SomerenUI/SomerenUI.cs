﻿using SomerenLogic;
using SomerenModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SomerenUI
{
    public partial class SomerenUI : Form
    {
        DrinksService drinksService = new DrinksService();
        ActivityService activityService = new ActivityService();
        public SomerenUI()
        {
            InitializeComponent();
        }

        private void SomerenUI_Load(object sender, EventArgs e)
        {
            showPanel("Dashboard");
        }

        private void showPanel(string panelName)
        {

            if (panelName == "Dashboard")
            {
                // hide all other panels
                pnlStudents.Hide();
                pnlTeacher.Hide();
                pnlRoom.Hide();
                pnlDrinks.Hide();
                pnlCRegister.Hide();
                pnlRevenueReport.Hide();
                pnlActivity.Hide();
                pnlAS.Hide();
                // show dashboard
                pnlDashboard.Show();
                imgDashboard.Show();
            }
            else if (panelName == "Students")
            {
                LoadStudents();
            }
            else if (panelName == "Lecturers")
            {
                LoadLecturers();
            }
            else if (panelName == "Rooms")
            {
                LoadRooms();
            }
            else if (panelName == "Drinks Supplies")
            {
                LoadDrinks();
            }
            else if (panelName == "Cash Register")
            {
                LoadCashRegister();
            }
            else if (panelName == "Revenue Report")
            {
                LoadRevenueReport();
            }
            else if (panelName == "Activities")
            {
                LoadActivities();
            }
            else if (panelName == "Supervisors")
            {
                LoadSupervisorActivity();
            }
            else if (panelName == "Participants")
            {
                LoadActivitiesOfParticipants();
            }

        }

        void LoadStudents()
        {
            // hide all other panels
            pnlDashboard.Hide();
            imgDashboard.Hide();
            pnlRoom.Hide();
            pnlTeacher.Hide();
            pnlDrinks.Hide();
            pnlCRegister.Hide();
            pnlRevenueReport.Hide();
            pnlActivity.Hide();
            pnlAS.Hide();
            // show students
            pnlStudents.Show();

            try
            {
                // fill the students listview within the students panel with a list of students
                StudentService studService = new StudentService();
                List<Student> studentList = studService.GetStudents();
                // clear the listview before filling it again
                listViewStudents.Items.Clear();

                foreach (Student s in studentList)
                {
                    ListViewItem list = new ListViewItem(s.Number.ToString());
                    list.SubItems.Add(s.FullName);
                    list.SubItems.Add(s.BirthDate.ToString("dd/MM/yyyy"));
                    list.SubItems.Add(s.LastName);

                    listViewStudents.Items.Add(list);

                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Something went wrong while loading the students: " + e.Message);
            }
        }

        void LoadLecturers()
        {
            // hide all other panels
            pnlDashboard.Hide();
            imgDashboard.Hide();
            pnlStudents.Hide();
            pnlRoom.Hide();
            pnlDrinks.Hide();
            pnlCRegister.Hide();
            pnlRevenueReport.Hide();
            pnlActivity.Hide();
            pnlAS.Hide();


            // show students
            pnlTeacher.Show();

            try
            {
                // fill the students listview within the students panel with a list of students
                TeacherService teacherService = new TeacherService();
                List<Teacher> teacherList = teacherService.GetTeacher();
                // clear the listview before filling it again
                listViewTeacher.Items.Clear();

                foreach (Teacher t in teacherList)
                {
                    ListViewItem list = new ListViewItem(t.TeacherID.ToString());
                    list.SubItems.Add(t.RoomID.ToString());
                    list.SubItems.Add(t.firstname);
                    list.SubItems.Add(t.lastname);
                    list.SubItems.Add(t.supervisor.ToString());

                    listViewTeacher.Items.Add(list);

                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Something went wrong while loading the teacher: " + e.Message);
            }
        }

        void LoadRooms()
        {
            // hide all other panels
            pnlDashboard.Hide();
            imgDashboard.Hide();
            pnlStudents.Hide();
            pnlTeacher.Hide();
            pnlDrinks.Hide();
            pnlCRegister.Hide();
            pnlRevenueReport.Hide();
            pnlActivity.Hide();
            pnlAS.Hide();


            // show Room
            pnlRoom.Show();

            try
            {
                // fill the students listview within the students panel with a list of students
                RoomService roomService = new RoomService();
                List<Room> roomList = roomService.GetRooms();
                // clear the listview before filling it again
                listViewRoom.Items.Clear();

                foreach (Room r in roomList)
                {
                    ListViewItem list = new ListViewItem(r.Number.ToString());
                    list.SubItems.Add(r.Type.ToString());
                    list.SubItems.Add(r.Capacity.ToString());


                    listViewRoom.Items.Add(list);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Something went wrong while loading the rooms: " + e.Message);
            }
        }

        void LoadDrinks()
        {
            // hide all other panels
            pnlDashboard.Hide();
            imgDashboard.Hide();
            pnlStudents.Hide();
            pnlTeacher.Hide();
            pnlRoom.Hide();
            pnlCRegister.Hide();
            pnlRevenueReport.Hide();
            pnlActivity.Hide();
            pnlAS.Hide();

            // show Room
            pnlDrinks.Show();

            try
            {
                // fill the students listview within the students panel with a list of students
                DrinksService drinksService = new DrinksService();
                List<Drink> drinkList = drinksService.GetDrinks();
                // clear the listview before filling it again
                listViewDrinks.Items.Clear();

                foreach (Drink drink in drinkList)
                {
                    ListViewItem list = new ListViewItem(drink.DrinkID.ToString());
                    list.SubItems.Add(drink.stock.ToString());
                    list.SubItems.Add(drink.Names);
                    list.SubItems.Add(drink.Sales_price.ToString());
                    list.SubItems.Add(drink.Drink_type);
                    list.Tag = drink;

                    listViewDrinks.Items.Add(list);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Something went wrong while loading the drinks supplies: " + e.Message);
            }
        }

        void LoadCashRegister()
        {
            pnlDashboard.Hide();
            imgDashboard.Hide();
            pnlStudents.Hide();
            pnlTeacher.Hide();
            pnlDrinks.Hide();
            pnlRoom.Hide();
            pnlRevenueReport.Hide();
            txtType.Hide();
            pnlActivity.Hide();
            pnlAS.Hide();

            // show Register
            pnlCRegister.Show();
            try
            {
                // fill the register listview 
                StudentService studService = new StudentService();
                List<Student> studentList = studService.GetStudents();
                DrinksService drinksService = new DrinksService();
                List<Drink> drinkList = drinksService.GetDrinks();
                // clear the listview before filling it again
                lvCStudent.Items.Clear();
                lvCDrink.Items.Clear();
                foreach (Student s in studentList)
                {
                    ListViewItem list = new ListViewItem(s.ToString());
                    list.Tag = s;
                    lvCStudent.Items.Add(list);
                }

                foreach (Drink drink in drinkList)
                {
                    ListViewItem list = new ListViewItem(drink.ToString());
                    list.SubItems.Add(drink.Sales_price.ToString());
                    list.SubItems.Add(drink.stock.ToString());
                    list.Tag = drink;
                    lvCDrink.Items.Add(list);
                }
                btnCheckout.Enabled = false;
                lblStudent.Visible = false;
                lblTotalprice.Visible = false;
            }
            catch (Exception e)
            {

                MessageBox.Show("Something went wrong while loading the Cash register: " + e.Message);
            }
        }
        void LoadRevenueReport()
        {
            pnlDashboard.Hide();
            imgDashboard.Hide();
            pnlStudents.Hide();
            pnlTeacher.Hide();
            pnlDrinks.Hide();
            pnlRoom.Hide();
            pnlCRegister.Hide();
            txtType.Hide();
            pnlActivity.Hide();
            pnlAS.Hide();

            // show Revenue Report
            pnlRevenueReport.Show();

        }
        void LoadActivities()
        {
            // hide all other panels
            pnlDashboard.Hide();
            imgDashboard.Hide();
            pnlStudents.Hide();
            pnlRoom.Hide();
            pnlDrinks.Hide();
            pnlCRegister.Hide();
            pnlRevenueReport.Hide();
            pnlAS.Hide();
            pnlTeacher.Hide();

            pnlActivity.Show();

            // show students

            try
            {
                // fill the students listview within the students panel with a list of students
                ActivityService activityservice = new ActivityService();
                List<Activity> activityList = activityservice.GetActivity();
                // clear the listview before filling it again
                listViewActivity.Items.Clear();

                foreach (Activity t in activityList)
                {
                    ListViewItem list = new ListViewItem(t.ActivityID.ToString());
                    list.SubItems.Add(t.Name.ToString());
                    list.SubItems.Add(t.StartDateTime.ToString());
                    list.SubItems.Add(t.EndDateTime.ToString());
                    list.Tag = t;
                    listViewActivity.Items.Add(list);

                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Something went wrong while loading the teacher: " + e.Message);
            }
        }
        void LoadSupervisorActivity()
        {
            pnlDashboard.Hide();
            imgDashboard.Hide();
            pnlStudents.Hide();
            pnlTeacher.Hide();
            pnlDrinks.Hide();
            pnlRoom.Hide();
            pnlCRegister.Hide();
            txtType.Hide();
            pnlActivity.Hide();
            pnlRevenueReport.Hide();

            // show activity
            pnlAS.Show();

            try
            {
                ActivityService activityService = new ActivityService();
                List<Activity> activityList = activityService.GetActivity();
                cmbActivities.Items.Clear();
                foreach (Activity activity in activityList)
                {
                    cmbActivities.Items.Add(activity);
                }

                cmbActivities.SelectedIndex = 0;

                TeacherService teacherService = new TeacherService();
                List<Teacher> teachers = teacherService.GetTeacher();
                cmbTeacher.Items.Clear();
                foreach (Teacher teacher in teachers)
                {
                    cmbTeacher.Items.Add(teacher);
                }
                cmbTeacher.SelectedIndex = 0;


            }
            catch (Exception e)
            {

                MessageBox.Show("Something went wrong while loading the Supervisors activities: " + e.Message);
            }

        }
        void LoadActivitiesOfParticipants()
        {
            pnlDashboard.Hide();
            imgDashboard.Hide();
            pnlStudents.Hide();
            pnlTeacher.Hide();
            pnlDrinks.Hide();
            pnlRoom.Hide();
            pnlCRegister.Hide();
            txtType.Hide();
            pnlActivity.Hide();
            pnlRevenueReport.Hide();
            pnlAS.Hide();

            // show participants
            pnlParticipants.Show();

            try
            {
                ActivityService activityService = new ActivityService();
                List<Activity> activityList = activityService.GetActivity();
                cmbParticipantsOfActivities.Items.Clear();
                foreach (Activity activity in activityList)
                {
                    cmbParticipantsOfActivities.Items.Add(activity);
                }

                cmbParticipantsOfActivities.SelectedIndex = 0;

                StudentService studentService = new StudentService();
                List<Student> student = studentService.GetStudents();
                cmbStudents.Items.Clear();
                foreach (Student s in student)
                {
                    cmbStudents.Items.Add(s);
                }
                cmbStudents.SelectedIndex = 0;


            }
            catch (Exception e)
            {
                MessageBox.Show("Something went wrong while loading the Participants activities: " + e.Message);
            }
        }

        private void dashboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dashboardToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            showPanel("Dashboard");
        }

        private void imgDashboard_Click(object sender, EventArgs e)
        {
            MessageBox.Show("What happens in Someren, stays in Someren!");
        }

        private void studentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Students");
        }

        private void lecturersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Lecturers");
        }

        private void roomsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Rooms");
        }
        private void drinksSuppliesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Drinks Supplies");
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtName.Text != "" && txtSales.Text != "" && txtStk.Text != "" && txtType.Text != "")
            {
                Drink d = new Drink()
                {
                    stock = int.Parse(txtStk.Text),
                    Names = txtName.Text,
                    Sales_price = int.Parse(txtSales.Text),
                    Drink_type = txtType.Text
                };
                drinksService.InsertDrink(d);

            }
            else
            {
                MessageBox.Show("Please fill in all the boxes: ");
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (listViewDrinks.SelectedItems.Count < 1)
            {
                return;
            }

            Drink drink = (Drink)listViewDrinks.SelectedItems[0].Tag;

            drinksService.RemoveDrink(drink);
        }
        private void updateActivity()
        {
            List<Activity> activityList = activityService.GetActivity();
            // clear the listview before filling it again
            listViewActivity.Items.Clear();

            foreach (Activity activity in activityList)
            {
                ListViewItem list = new ListViewItem(activity.ActivityID.ToString());
                list.SubItems.Add(activity.Name);
                list.SubItems.Add(activity.StartDateTime.ToString());
                list.SubItems.Add(activity.EndDateTime.ToString());
                list.Tag = activity;

                listViewActivity.Items.Add(list);
            }
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            if (txtDrinkID.Text != "" && txtName.Text != "" && txtSales.Text != "" && txtStk.Text != "" && txtType.Text != "")
            {
                Drink d = new Drink()
                {
                    DrinkID = int.Parse(txtDrinkID.Text),
                    stock = int.Parse(txtStk.Text),
                    Names = txtName.Text,
                    Sales_price = int.Parse(txtSales.Text),
                    Drink_type = txtType.Text
                };
                drinksService.ChangeDrink(d);
                updateDrink();

            }
            else
            {
                MessageBox.Show("Please fill in all the boxes: ");
            }


        }
        private void updateDrink()
        {
            List<Drink> drinkList = drinksService.GetDrinks();
            // clear the listview before filling it again
            listViewDrinks.Items.Clear();

            foreach (Drink drink in drinkList)
            {
                ListViewItem list = new ListViewItem(drink.DrinkID.ToString());
                list.SubItems.Add(drink.stock.ToString());
                list.SubItems.Add(drink.Names);
                list.SubItems.Add(drink.Sales_price.ToString());
                list.SubItems.Add(drink.Drink_type);
                list.Tag = drink;

                listViewDrinks.Items.Add(list);
            }
        }

        private void cashRegisterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Cash Register");
        }

        private void lvCStudent_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvCStudent.SelectedItems.Count == 1)
            {
                ListViewItem lvC = lvCStudent.SelectedItems[0];
                Student student = (Student)lvC.Tag;
                lblStudent.Text = student.ToString();

            }
            ListViewClick();
        }

        private void lvCDrink_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (lvCDrink.SelectedItems.Count >= 0)
            {
                int addPrice = 0;
                foreach (ListViewItem lvD in lvCDrink.SelectedItems)
                {
                    Drink drink = (Drink)lvD.Tag;
                    addPrice += drink.Sales_price;
                }

                lblTotalprice.Text = addPrice.ToString("\u20AC 0.00");
            }

            ListViewClick();
        }

        void ListViewClick()
        {
            if (lvCDrink.SelectedItems.Count > 0 & lvCStudent.SelectedItems.Count > 0)
            {
                btnCheckout.Enabled = true;
                lblStudent.Visible = true;
                lblTotalprice.Visible = true;
            }
            else
            {
                btnCheckout.Enabled = false;
            }

        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {

            CashRegisterService cashRegister = new CashRegisterService();


            foreach (ListViewItem lvD in lvCDrink.SelectedItems)
            {
                Drink drink = (Drink)lvD.Tag;
                drink.stock--;
                cashRegister.UpdateStock(drink);

                Student student = (Student)lvCStudent.SelectedItems[0].Tag;

                cashRegister.DrinkSale(drink, student);
            }
            LoadCashRegister();

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void revenueReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Revenue Report");
        }

        private void labelNumOfCustomers_Click(object sender, EventArgs e)
        {

        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            DateTime startdate = dateTimePickerStartDate.Value;
            DateTime enddate = dateTimePickerEndDate.Value;
            ReportRevenueService reportRevenueService = new ReportRevenueService(startdate, enddate);
            labelSales.Text = reportRevenueService.Sales.ToString();
            labelTurnOver.Text = reportRevenueService.TurnOver.ToString();
            labelNumOfCustomers.Text = reportRevenueService.NumberOfCustomers.ToString();
        }

        public bool ConfirmationOfDates()
        {
            DateTime startdate = dateTimePickerStartDate.Value;
            DateTime enddate = dateTimePickerEndDate.Value;
            if (enddate >= startdate)
            {
                if (enddate.Date <= DateTime.Now.Date)
                {
                    btnReport.Enabled = true;
                    labelErrorFounder.Text = null;
                }
                else
                {
                    labelErrorFounder.Text = "Please re-check and give a valid EndDate before the StartDate.";
                    btnReport.Enabled = false;
                }
            }
            else
            {
                labelErrorFounder.Text = "Please re-check and give a valid EndDate after the StartDate.";
                btnReport.Enabled = false;
            }
            return true;
        }

        private void dateTimePickerStartDate_ValueChanged(object sender, EventArgs e)
        {
            ConfirmationOfDates();
        }

        private void dateTimePickerEndDate_ValueChanged(object sender, EventArgs e)
        {
            ConfirmationOfDates();
        }

        private void activitiesToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

            showPanel("Activities");

        }

        private void butadd_Click_1(object sender, EventArgs e)
        {


            if (txtnameactivity.Text == "" || txtnameactivity.Text.Length < 2)
            {
                MessageBox.Show("Please fill in all the boxes: ");


            }
            else
            {
                Activity ac = new Activity()
                {
                    Name = txtnameactivity.Text,
                    StartDateTime = Convert.ToDateTime(dateStart.Value),
                    EndDateTime = Convert.ToDateTime(dateEnd.Value)
                };
                activityService.InsertActivity(ac);

            }
            
            updateActivity();

        }

        private void butchange_Click_1(object sender, EventArgs e)
        {
            if (txtnameactivity.Text == "" && dateStart.Text == "" && dateEnd.Text == "")
            {
                MessageBox.Show("Please fill in all the boxes: ");
            }
            else
            {
                Activity acti = new Activity()
                {
                    ActivityID = int.Parse(txtActivityid.Text),
                    Name = txtnameactivity.Text,
                    StartDateTime = Convert.ToDateTime(dateStart.Value),
                    EndDateTime = Convert.ToDateTime(dateEnd.Value)
                };
                activityService.ChangeActivity(acti);
                updateActivity();
            }
            updateActivity();
        }

        private void butremove_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to remove this activity?", "Warning", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                if (listViewActivity.SelectedItems.Count < 1)
                {
                    return;
                }
                Activity activity = (Activity)listViewActivity.SelectedItems[0].Tag;

                activityService.RemoveActivity(activity);
            }
            else if (dialogResult == DialogResult.No)
            {
                return;
            }
            updateActivity();

        }
        
        private void supervisorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Supervisors");
        }

        private void cmbActivities_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                // fill the supervisor listview within the supervisor panel with a list of supervisor
                SupervisorService supervisorService = new SupervisorService();
                List<Supervisor> supervisorList = supervisorService.GetStupervisors();
                Activity activity = (Activity)cmbActivities.SelectedItem;
                // clear the listview before filling it again
                lvSupervisorActivities.Items.Clear();
                lblActivity.Text = activity.Name;
                foreach (Supervisor supervisor in supervisorList)
                {
                    if (supervisor.activityId == activity.ActivityID)
                    {
                        ListViewItem list = new ListViewItem(supervisor.TeacherFullName);
                        list.SubItems.Add(activity.Name.ToString());

                        lvSupervisorActivities.Items.Add(list);
                        list.Tag = supervisor;
                    }
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show("Something went wrong while loading the  activities: " + exp.Message);
            }
            
        }

        private void btnAddSupervisor_Click(object sender, EventArgs e)
        {
            try
            {
                Teacher teacher = (Teacher)cmbTeacher.SelectedItem;
                Activity activity = (Activity)cmbActivities.SelectedItem;
                SupervisorService supervisorService = new SupervisorService();
                supervisorService.AddSupervisors(teacher, activity);
                LoadSupervisorActivity();
            }
            catch (Exception exp)
            {
                MessageBox.Show("Something went wrong while adding the  supervisors: " + exp.Message);
            }
            
        }

        private void btnRemoveSupervisor_Click(object sender, EventArgs e)
        {
            try
            {
                if (lvSupervisorActivities.SelectedItems.Count >= 0)
                {

                    if (MessageBox.Show("Are you sure you want to Remove Supervisor", "Important", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        foreach (ListViewItem lvD in lvSupervisorActivities.SelectedItems)
                        {
                            Supervisor supervisor = (Supervisor)lvD.Tag;
                            // supervisor.TeacherFullName = cmbTeacher.SelectedIndex.ToString();
                            SupervisorService supervisorService = new SupervisorService();
                            supervisorService.Remove(supervisor);

                        }
                    }
                    else
                    {
                        return;
                    }
                    LoadSupervisorActivity();
                }
            }
            catch (Exception exp)
            {

                MessageBox.Show("Something went wrong while Removing the  supervisors: " + exp.Message);
            }
        }
        private void cmbParticipantsOfActivities_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                // fill the participants listview within the participants panel with a list of participants
                ActivityParticipantsService activityParticipantsService = new ActivityParticipantsService();
                List<ActivityParticipants> activityParticipantsList = activityParticipantsService.GetParticipant();
                Activity activity = (Activity)cmbParticipantsOfActivities.SelectedItem;
                // clear the listview before filling it again
                lvParticipantActivities.Items.Clear();
                lblParticipant.Text = activity.Name;
                foreach (ActivityParticipants participant in activityParticipantsList)
                {
                    if (participant.activityId == activity.ActivityID)
                    {
                        ListViewItem listofparticipants = new ListViewItem(participant.StudentFullName);
                        listofparticipants.SubItems.Add(activity.Name.ToString());

                        lvParticipantActivities.Items.Add(listofparticipants);
                        listofparticipants.Tag = participant;
                    }
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show("Something went wrong while loading the  participants: " + exp.Message);
            }
            
        }

        private void btnAddParticipant_Click(object sender, EventArgs e)
        {
            try
            {
                Student student = (Student)cmbStudents.SelectedItem;
                Activity activity = (Activity)cmbParticipantsOfActivities.SelectedItem;
                ActivityParticipantsService activityParticipantsService = new ActivityParticipantsService();
                activityParticipantsService.AddParticipants(student, activity);

                LoadActivitiesOfParticipants();
            }
            catch (Exception exp)
            {
                MessageBox.Show("Something went wrong while adding the  participants: " + exp.Message);
            }
            
        }

        private void btnRemoveParticipant_Click(object sender, EventArgs e)
        {
            try
            {
                if (lvParticipantActivities.SelectedItems.Count >= 0)
                {

                    if (MessageBox.Show("Are you sure you want to Remove Participant?", "Warning!", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        foreach (ListViewItem lvP in lvParticipantActivities.SelectedItems)
                        {
                            ActivityParticipants participant = (ActivityParticipants)lvP.Tag;
                            // supervisor.TeacherFullName = cmbTeacher.SelectedIndex.ToString();
                            ActivityParticipantsService activityParticipantsService = new ActivityParticipantsService();
                            activityParticipantsService.RemoveParticipants(participant);

                        }
                    }
                    else
                    {
                        return;
                    }
                    LoadActivitiesOfParticipants();
                }

            }
            catch (Exception exp)
            {
                MessageBox.Show("Something went wrong while loading the  participants: " + exp.Message);
            }
            
        }

        private void participantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Participants");
        }
    }
}