﻿namespace SomerenUI
{
    partial class SomerenUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SomerenUI));
            this.imgDashboard = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.dashboardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dashboardToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lecturersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.activitiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.roomsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.drinksSuppliesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cashRegisterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revenueReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.supervisorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.participantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlDashboard = new System.Windows.Forms.Panel();
            this.lbl_Dashboard = new System.Windows.Forms.Label();
            this.pnlActivity = new System.Windows.Forms.Panel();
            this.dateEnd = new System.Windows.Forms.DateTimePicker();
            this.dateStart = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.txtActivityid = new System.Windows.Forms.TextBox();
            this.butremove = new System.Windows.Forms.Button();
            this.butchange = new System.Windows.Forms.Button();
            this.butadd = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtnameacti = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtnameactivity = new System.Windows.Forms.TextBox();
            this.listViewActivity = new System.Windows.Forms.ListView();
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.pnlStudents = new System.Windows.Forms.Panel();
            this.listViewStudents = new System.Windows.Forms.ListView();
            this.studentID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.studentName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.studentDOB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbl_Students = new System.Windows.Forms.Label();
            this.pnlTeacher = new System.Windows.Forms.Panel();
            this.listViewTeacher = new System.Windows.Forms.ListView();
            this.TeacherID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.RoomID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.firstname = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lastname = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.supervisor = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lbl_Teacher = new System.Windows.Forms.Label();
            this.pnlRoom = new System.Windows.Forms.Panel();
            this.listViewRoom = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlDrinks = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDrinkID = new System.Windows.Forms.TextBox();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnChange = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblType = new System.Windows.Forms.Label();
            this.lblStock = new System.Windows.Forms.Label();
            this.lblNames = new System.Windows.Forms.Label();
            this.lblSales = new System.Windows.Forms.Label();
            this.lblDrinkID = new System.Windows.Forms.Label();
            this.txtSales = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtStk = new System.Windows.Forms.TextBox();
            this.txtType = new System.Windows.Forms.TextBox();
            this.listViewDrinks = new System.Windows.Forms.ListView();
            this.drinkid = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.lblDrink = new System.Windows.Forms.Label();
            this.pnlCRegister = new System.Windows.Forms.Panel();
            this.lblTotalprice = new System.Windows.Forms.Label();
            this.lblStudent = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnCheckout = new System.Windows.Forms.Button();
            this.lvCDrink = new System.Windows.Forms.ListView();
            this.Drink = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvCStudent = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.pnlRevenueReport = new System.Windows.Forms.Panel();
            this.labelErrorFounder = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnReport = new System.Windows.Forms.Button();
            this.labelNumOfCustomers = new System.Windows.Forms.Label();
            this.labelTurnOver = new System.Windows.Forms.Label();
            this.labelSales = new System.Windows.Forms.Label();
            this.dateTimePickerEndDate = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerStartDate = new System.Windows.Forms.DateTimePicker();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.label26 = new System.Windows.Forms.Label();
            this.pnlAS = new System.Windows.Forms.Panel();
            this.cmbTeacher = new System.Windows.Forms.ComboBox();
            this.cmbActivities = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.lblActivity = new System.Windows.Forms.Label();
            this.btnRemoveSupervisor = new System.Windows.Forms.Button();
            this.btnAddSupervisor = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lvSupervisorActivities = new System.Windows.Forms.ListView();
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label20 = new System.Windows.Forms.Label();
            this.pnlParticipants = new System.Windows.Forms.Panel();
            this.cmbStudents = new System.Windows.Forms.ComboBox();
            this.cmbParticipantsOfActivities = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lblParticipant = new System.Windows.Forms.Label();
            this.btnRemoveParticipant = new System.Windows.Forms.Button();
            this.btnAddParticipant = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lvParticipantActivities = new System.Windows.Forms.ListView();
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label23 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.imgDashboard)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.pnlDashboard.SuspendLayout();
            this.pnlActivity.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.pnlStudents.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlTeacher.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.pnlRoom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.pnlDrinks.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.pnlCRegister.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.pnlRevenueReport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.pnlAS.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.pnlParticipants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.SuspendLayout();
            // 
            // imgDashboard
            // 
            this.imgDashboard.Location = new System.Drawing.Point(836, 0);
            this.imgDashboard.Margin = new System.Windows.Forms.Padding(4);
            this.imgDashboard.Name = "imgDashboard";
            this.imgDashboard.Size = new System.Drawing.Size(413, 332);
            this.imgDashboard.TabIndex = 0;
            this.imgDashboard.TabStop = false;
            this.imgDashboard.Click += new System.EventHandler(this.imgDashboard_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dashboardToolStripMenuItem,
            this.studentsToolStripMenuItem,
            this.lecturersToolStripMenuItem,
            this.activitiesToolStripMenuItem,
            this.roomsToolStripMenuItem,
            this.drinksSuppliesToolStripMenuItem,
            this.cashRegisterToolStripMenuItem,
            this.revenueReportToolStripMenuItem,
            this.supervisorToolStripMenuItem,
            this.participantsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1750, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // dashboardToolStripMenuItem
            // 
            this.dashboardToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dashboardToolStripMenuItem1,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.dashboardToolStripMenuItem.Name = "dashboardToolStripMenuItem";
            this.dashboardToolStripMenuItem.Size = new System.Drawing.Size(100, 24);
            this.dashboardToolStripMenuItem.Text = "Application";
            this.dashboardToolStripMenuItem.Click += new System.EventHandler(this.dashboardToolStripMenuItem_Click);
            // 
            // dashboardToolStripMenuItem1
            // 
            this.dashboardToolStripMenuItem1.Name = "dashboardToolStripMenuItem1";
            this.dashboardToolStripMenuItem1.Size = new System.Drawing.Size(165, 26);
            this.dashboardToolStripMenuItem1.Text = "Dashboard";
            this.dashboardToolStripMenuItem1.Click += new System.EventHandler(this.dashboardToolStripMenuItem1_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(162, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // studentsToolStripMenuItem
            // 
            this.studentsToolStripMenuItem.Name = "studentsToolStripMenuItem";
            this.studentsToolStripMenuItem.Size = new System.Drawing.Size(80, 24);
            this.studentsToolStripMenuItem.Text = "Students";
            this.studentsToolStripMenuItem.Click += new System.EventHandler(this.studentsToolStripMenuItem_Click);
            // 
            // lecturersToolStripMenuItem
            // 
            this.lecturersToolStripMenuItem.Name = "lecturersToolStripMenuItem";
            this.lecturersToolStripMenuItem.Size = new System.Drawing.Size(82, 24);
            this.lecturersToolStripMenuItem.Text = "Lecturers";
            this.lecturersToolStripMenuItem.Click += new System.EventHandler(this.lecturersToolStripMenuItem_Click);
            // 
            // activitiesToolStripMenuItem
            // 
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.activitiesToolStripMenuItem.Text = "Activities";
            this.activitiesToolStripMenuItem.Click += new System.EventHandler(this.activitiesToolStripMenuItem_Click_1);
            // 
            // roomsToolStripMenuItem
            // 
            this.roomsToolStripMenuItem.Name = "roomsToolStripMenuItem";
            this.roomsToolStripMenuItem.Size = new System.Drawing.Size(69, 24);
            this.roomsToolStripMenuItem.Text = "Rooms";
            this.roomsToolStripMenuItem.Click += new System.EventHandler(this.roomsToolStripMenuItem_Click);
            // 
            // drinksSuppliesToolStripMenuItem
            // 
            this.drinksSuppliesToolStripMenuItem.Name = "drinksSuppliesToolStripMenuItem";
            this.drinksSuppliesToolStripMenuItem.Size = new System.Drawing.Size(124, 24);
            this.drinksSuppliesToolStripMenuItem.Text = "Drinks Supplies";
            this.drinksSuppliesToolStripMenuItem.Click += new System.EventHandler(this.drinksSuppliesToolStripMenuItem_Click);
            // 
            // cashRegisterToolStripMenuItem
            // 
            this.cashRegisterToolStripMenuItem.Name = "cashRegisterToolStripMenuItem";
            this.cashRegisterToolStripMenuItem.Size = new System.Drawing.Size(112, 24);
            this.cashRegisterToolStripMenuItem.Text = "Cash Register";
            this.cashRegisterToolStripMenuItem.Click += new System.EventHandler(this.cashRegisterToolStripMenuItem_Click);
            // 
            // revenueReportToolStripMenuItem
            // 
            this.revenueReportToolStripMenuItem.Name = "revenueReportToolStripMenuItem";
            this.revenueReportToolStripMenuItem.Size = new System.Drawing.Size(128, 24);
            this.revenueReportToolStripMenuItem.Text = "Revenue Report";
            this.revenueReportToolStripMenuItem.Click += new System.EventHandler(this.revenueReportToolStripMenuItem_Click);
            // 
            // supervisorToolStripMenuItem
            // 
            this.supervisorToolStripMenuItem.Name = "supervisorToolStripMenuItem";
            this.supervisorToolStripMenuItem.Size = new System.Drawing.Size(92, 24);
            this.supervisorToolStripMenuItem.Text = "Supervisor";
            this.supervisorToolStripMenuItem.Click += new System.EventHandler(this.supervisorToolStripMenuItem_Click);
            // 
            // participantsToolStripMenuItem
            // 
            this.participantsToolStripMenuItem.Name = "participantsToolStripMenuItem";
            this.participantsToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.participantsToolStripMenuItem.Text = "Participants";
            this.participantsToolStripMenuItem.Click += new System.EventHandler(this.participantsToolStripMenuItem_Click);
            // 
            // pnlDashboard
            // 
            this.pnlDashboard.Controls.Add(this.lbl_Dashboard);
            this.pnlDashboard.Controls.Add(this.imgDashboard);
            this.pnlDashboard.Location = new System.Drawing.Point(0, 39);
            this.pnlDashboard.Margin = new System.Windows.Forms.Padding(4);
            this.pnlDashboard.Name = "pnlDashboard";
            this.pnlDashboard.Size = new System.Drawing.Size(1351, 574);
            this.pnlDashboard.TabIndex = 2;
            // 
            // lbl_Dashboard
            // 
            this.lbl_Dashboard.AutoSize = true;
            this.lbl_Dashboard.Location = new System.Drawing.Point(19, 16);
            this.lbl_Dashboard.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Dashboard.Name = "lbl_Dashboard";
            this.lbl_Dashboard.Size = new System.Drawing.Size(243, 17);
            this.lbl_Dashboard.TabIndex = 1;
            this.lbl_Dashboard.Text = "Welcome to the Someren Application!";
            // 
            // pnlActivity
            // 
            this.pnlActivity.Controls.Add(this.dateEnd);
            this.pnlActivity.Controls.Add(this.dateStart);
            this.pnlActivity.Controls.Add(this.label12);
            this.pnlActivity.Controls.Add(this.txtActivityid);
            this.pnlActivity.Controls.Add(this.butremove);
            this.pnlActivity.Controls.Add(this.butchange);
            this.pnlActivity.Controls.Add(this.butadd);
            this.pnlActivity.Controls.Add(this.label13);
            this.pnlActivity.Controls.Add(this.label14);
            this.pnlActivity.Controls.Add(this.txtnameacti);
            this.pnlActivity.Controls.Add(this.label16);
            this.pnlActivity.Controls.Add(this.txtnameactivity);
            this.pnlActivity.Controls.Add(this.listViewActivity);
            this.pnlActivity.Controls.Add(this.pictureBox7);
            this.pnlActivity.Controls.Add(this.label11);
            this.pnlActivity.Location = new System.Drawing.Point(0, 42);
            this.pnlActivity.Margin = new System.Windows.Forms.Padding(4);
            this.pnlActivity.Name = "pnlActivity";
            this.pnlActivity.Size = new System.Drawing.Size(1261, 575);
            this.pnlActivity.TabIndex = 6;
            // 
            // dateEnd
            // 
            this.dateEnd.Location = new System.Drawing.Point(769, 134);
            this.dateEnd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateEnd.Name = "dateEnd";
            this.dateEnd.Size = new System.Drawing.Size(177, 22);
            this.dateEnd.TabIndex = 35;
            // 
            // dateStart
            // 
            this.dateStart.Location = new System.Drawing.Point(769, 96);
            this.dateStart.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateStart.Name = "dateStart";
            this.dateStart.Size = new System.Drawing.Size(177, 22);
            this.dateStart.TabIndex = 34;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(691, 175);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 17);
            this.label12.TabIndex = 33;
            this.label12.Text = "ActivityID";
            // 
            // txtActivityid
            // 
            this.txtActivityid.Location = new System.Drawing.Point(769, 170);
            this.txtActivityid.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtActivityid.Name = "txtActivityid";
            this.txtActivityid.Size = new System.Drawing.Size(89, 22);
            this.txtActivityid.TabIndex = 32;
            // 
            // butremove
            // 
            this.butremove.Location = new System.Drawing.Point(776, 354);
            this.butremove.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.butremove.Name = "butremove";
            this.butremove.Size = new System.Drawing.Size(115, 34);
            this.butremove.TabIndex = 31;
            this.butremove.Text = "Remove";
            this.butremove.UseVisualStyleBackColor = true;
            this.butremove.Click += new System.EventHandler(this.butremove_Click);
            // 
            // butchange
            // 
            this.butchange.Location = new System.Drawing.Point(776, 302);
            this.butchange.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.butchange.Name = "butchange";
            this.butchange.Size = new System.Drawing.Size(115, 34);
            this.butchange.TabIndex = 30;
            this.butchange.Text = "Change";
            this.butchange.UseVisualStyleBackColor = true;
            this.butchange.Click += new System.EventHandler(this.butchange_Click_1);
            // 
            // butadd
            // 
            this.butadd.Location = new System.Drawing.Point(776, 251);
            this.butadd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.butadd.Name = "butadd";
            this.butadd.Size = new System.Drawing.Size(115, 34);
            this.butadd.TabIndex = 29;
            this.butadd.Text = "Add";
            this.butadd.UseVisualStyleBackColor = true;
            this.butadd.Click += new System.EventHandler(this.butadd_Click_1);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(667, 135);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(94, 17);
            this.label13.TabIndex = 28;
            this.label13.Text = "EndDateTime";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(663, 98);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(99, 17);
            this.label14.TabIndex = 27;
            this.label14.Text = "SatrtDateTime";
            // 
            // txtnameacti
            // 
            this.txtnameacti.AutoSize = true;
            this.txtnameacti.Location = new System.Drawing.Point(691, 52);
            this.txtnameacti.Name = "txtnameacti";
            this.txtnameacti.Size = new System.Drawing.Size(45, 17);
            this.txtnameacti.TabIndex = 26;
            this.txtnameacti.Text = "Name";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(659, 164);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(0, 17);
            this.label16.TabIndex = 25;
            // 
            // txtnameactivity
            // 
            this.txtnameactivity.Location = new System.Drawing.Point(776, 52);
            this.txtnameactivity.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtnameactivity.Name = "txtnameactivity";
            this.txtnameactivity.Size = new System.Drawing.Size(89, 22);
            this.txtnameactivity.TabIndex = 23;
            // 
            // listViewActivity
            // 
            this.listViewActivity.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader9,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14});
            this.listViewActivity.FullRowSelect = true;
            this.listViewActivity.HideSelection = false;
            this.listViewActivity.Location = new System.Drawing.Point(21, 52);
            this.listViewActivity.Margin = new System.Windows.Forms.Padding(4);
            this.listViewActivity.Name = "listViewActivity";
            this.listViewActivity.Size = new System.Drawing.Size(633, 377);
            this.listViewActivity.TabIndex = 5;
            this.listViewActivity.UseCompatibleStateImageBehavior = false;
            this.listViewActivity.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "ActivityID";
            this.columnHeader9.Width = 85;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Name";
            this.columnHeader12.Width = 62;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "StartDateTime";
            this.columnHeader13.Width = 119;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "EndDateTime";
            this.columnHeader14.Width = 113;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox7.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox7.InitialImage")));
            this.pictureBox7.Location = new System.Drawing.Point(1075, 0);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(173, 151);
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(28, 12);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(132, 33);
            this.label11.TabIndex = 3;
            this.label11.Text = "Activities";
            // 
            // pnlStudents
            // 
            this.pnlStudents.Controls.Add(this.listViewStudents);
            this.pnlStudents.Controls.Add(this.pictureBox1);
            this.pnlStudents.Controls.Add(this.lbl_Students);
            this.pnlStudents.Location = new System.Drawing.Point(0, 43);
            this.pnlStudents.Margin = new System.Windows.Forms.Padding(4);
            this.pnlStudents.Name = "pnlStudents";
            this.pnlStudents.Size = new System.Drawing.Size(1251, 574);
            this.pnlStudents.TabIndex = 4;
            // 
            // listViewStudents
            // 
            this.listViewStudents.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.studentID,
            this.studentName,
            this.studentDOB});
            this.listViewStudents.HideSelection = false;
            this.listViewStudents.Location = new System.Drawing.Point(21, 52);
            this.listViewStudents.Margin = new System.Windows.Forms.Padding(4);
            this.listViewStudents.Name = "listViewStudents";
            this.listViewStudents.Size = new System.Drawing.Size(1020, 377);
            this.listViewStudents.TabIndex = 5;
            this.listViewStudents.UseCompatibleStateImageBehavior = false;
            this.listViewStudents.View = System.Windows.Forms.View.Details;
            // 
            // studentID
            // 
            this.studentID.Text = "ID";
            this.studentID.Width = 100;
            // 
            // studentName
            // 
            this.studentName.Text = "Name";
            this.studentName.Width = 100;
            // 
            // studentDOB
            // 
            this.studentDOB.Text = "Date of Birth";
            this.studentDOB.Width = 100;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(1075, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(173, 151);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lbl_Students
            // 
            this.lbl_Students.AutoSize = true;
            this.lbl_Students.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Students.Location = new System.Drawing.Point(13, 12);
            this.lbl_Students.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Students.Name = "lbl_Students";
            this.lbl_Students.Size = new System.Drawing.Size(129, 33);
            this.lbl_Students.TabIndex = 3;
            this.lbl_Students.Text = "Students";
            // 
            // pnlTeacher
            // 
            this.pnlTeacher.Controls.Add(this.listViewTeacher);
            this.pnlTeacher.Controls.Add(this.pictureBox2);
            this.pnlTeacher.Controls.Add(this.lbl_Teacher);
            this.pnlTeacher.Location = new System.Drawing.Point(0, 42);
            this.pnlTeacher.Margin = new System.Windows.Forms.Padding(4);
            this.pnlTeacher.Name = "pnlTeacher";
            this.pnlTeacher.Size = new System.Drawing.Size(1251, 574);
            this.pnlTeacher.TabIndex = 5;
            // 
            // listViewTeacher
            // 
            this.listViewTeacher.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.TeacherID,
            this.RoomID,
            this.firstname,
            this.lastname,
            this.supervisor});
            this.listViewTeacher.HideSelection = false;
            this.listViewTeacher.Location = new System.Drawing.Point(21, 52);
            this.listViewTeacher.Margin = new System.Windows.Forms.Padding(4);
            this.listViewTeacher.Name = "listViewTeacher";
            this.listViewTeacher.Size = new System.Drawing.Size(1020, 377);
            this.listViewTeacher.TabIndex = 5;
            this.listViewTeacher.UseCompatibleStateImageBehavior = false;
            this.listViewTeacher.View = System.Windows.Forms.View.Details;
            // 
            // TeacherID
            // 
            this.TeacherID.Text = "TeacherID";
            this.TeacherID.Width = 100;
            // 
            // RoomID
            // 
            this.RoomID.Text = "RoomID";
            this.RoomID.Width = 100;
            // 
            // firstname
            // 
            this.firstname.Text = "firstname";
            this.firstname.Width = 100;
            // 
            // lastname
            // 
            this.lastname.Text = "lastname";
            this.lastname.Width = 100;
            // 
            // supervisor
            // 
            this.supervisor.Text = "supervisor";
            this.supervisor.Width = 100;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.InitialImage")));
            this.pictureBox2.Location = new System.Drawing.Point(1075, 0);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(173, 151);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // lbl_Teacher
            // 
            this.lbl_Teacher.AutoSize = true;
            this.lbl_Teacher.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Teacher.Location = new System.Drawing.Point(13, 12);
            this.lbl_Teacher.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Teacher.Name = "lbl_Teacher";
            this.lbl_Teacher.Size = new System.Drawing.Size(137, 33);
            this.lbl_Teacher.TabIndex = 3;
            this.lbl_Teacher.Text = "Lecturers";
            // 
            // pnlRoom
            // 
            this.pnlRoom.Controls.Add(this.listViewRoom);
            this.pnlRoom.Controls.Add(this.pictureBox3);
            this.pnlRoom.Controls.Add(this.label1);
            this.pnlRoom.Location = new System.Drawing.Point(0, 42);
            this.pnlRoom.Margin = new System.Windows.Forms.Padding(4);
            this.pnlRoom.Name = "pnlRoom";
            this.pnlRoom.Size = new System.Drawing.Size(1251, 574);
            this.pnlRoom.TabIndex = 6;
            // 
            // listViewRoom
            // 
            this.listViewRoom.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.listViewRoom.HideSelection = false;
            this.listViewRoom.Location = new System.Drawing.Point(21, 52);
            this.listViewRoom.Margin = new System.Windows.Forms.Padding(4);
            this.listViewRoom.Name = "listViewRoom";
            this.listViewRoom.Size = new System.Drawing.Size(1020, 377);
            this.listViewRoom.TabIndex = 5;
            this.listViewRoom.UseCompatibleStateImageBehavior = false;
            this.listViewRoom.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Room ID";
            this.columnHeader1.Width = 100;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Type";
            this.columnHeader2.Width = 100;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Capacity";
            this.columnHeader3.Width = 100;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox3.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.InitialImage")));
            this.pictureBox3.Location = new System.Drawing.Point(1075, 0);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(173, 151);
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 12);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 33);
            this.label1.TabIndex = 3;
            this.label1.Text = "Rooms";
            // 
            // pnlDrinks
            // 
            this.pnlDrinks.Controls.Add(this.label2);
            this.pnlDrinks.Controls.Add(this.txtDrinkID);
            this.pnlDrinks.Controls.Add(this.btnRemove);
            this.pnlDrinks.Controls.Add(this.btnChange);
            this.pnlDrinks.Controls.Add(this.btnAdd);
            this.pnlDrinks.Controls.Add(this.lblType);
            this.pnlDrinks.Controls.Add(this.lblStock);
            this.pnlDrinks.Controls.Add(this.lblNames);
            this.pnlDrinks.Controls.Add(this.lblSales);
            this.pnlDrinks.Controls.Add(this.lblDrinkID);
            this.pnlDrinks.Controls.Add(this.txtSales);
            this.pnlDrinks.Controls.Add(this.txtName);
            this.pnlDrinks.Controls.Add(this.txtStk);
            this.pnlDrinks.Controls.Add(this.txtType);
            this.pnlDrinks.Controls.Add(this.listViewDrinks);
            this.pnlDrinks.Controls.Add(this.pictureBox4);
            this.pnlDrinks.Controls.Add(this.lblDrink);
            this.pnlDrinks.Location = new System.Drawing.Point(4, 42);
            this.pnlDrinks.Margin = new System.Windows.Forms.Padding(4);
            this.pnlDrinks.Name = "pnlDrinks";
            this.pnlDrinks.Size = new System.Drawing.Size(1251, 574);
            this.pnlDrinks.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(683, 214);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 17);
            this.label2.TabIndex = 20;
            this.label2.Text = "DrinkID";
            // 
            // txtDrinkID
            // 
            this.txtDrinkID.Location = new System.Drawing.Point(787, 210);
            this.txtDrinkID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDrinkID.Name = "txtDrinkID";
            this.txtDrinkID.Size = new System.Drawing.Size(89, 22);
            this.txtDrinkID.TabIndex = 19;
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(787, 366);
            this.btnRemove.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(115, 34);
            this.btnRemove.TabIndex = 18;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnChange
            // 
            this.btnChange.Location = new System.Drawing.Point(787, 314);
            this.btnChange.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(115, 34);
            this.btnChange.TabIndex = 17;
            this.btnChange.Text = "Change";
            this.btnChange.UseVisualStyleBackColor = true;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(787, 262);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(115, 34);
            this.btnAdd.TabIndex = 16;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(675, 138);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(76, 17);
            this.lblType.TabIndex = 15;
            this.lblType.Text = "Drink_type";
            // 
            // lblStock
            // 
            this.lblStock.AutoSize = true;
            this.lblStock.Location = new System.Drawing.Point(707, 103);
            this.lblStock.Name = "lblStock";
            this.lblStock.Size = new System.Drawing.Size(43, 17);
            this.lblStock.TabIndex = 14;
            this.lblStock.Text = "Stock";
            // 
            // lblNames
            // 
            this.lblNames.AutoSize = true;
            this.lblNames.Location = new System.Drawing.Point(707, 57);
            this.lblNames.Name = "lblNames";
            this.lblNames.Size = new System.Drawing.Size(52, 17);
            this.lblNames.TabIndex = 13;
            this.lblNames.Text = "Names";
            // 
            // lblSales
            // 
            this.lblSales.AutoSize = true;
            this.lblSales.Location = new System.Drawing.Point(668, 174);
            this.lblSales.Name = "lblSales";
            this.lblSales.Size = new System.Drawing.Size(82, 17);
            this.lblSales.TabIndex = 12;
            this.lblSales.Text = "Sales_price";
            // 
            // lblDrinkID
            // 
            this.lblDrinkID.AutoSize = true;
            this.lblDrinkID.Location = new System.Drawing.Point(569, 54);
            this.lblDrinkID.Name = "lblDrinkID";
            this.lblDrinkID.Size = new System.Drawing.Size(0, 17);
            this.lblDrinkID.TabIndex = 11;
            // 
            // txtSales
            // 
            this.txtSales.Location = new System.Drawing.Point(787, 170);
            this.txtSales.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSales.Name = "txtSales";
            this.txtSales.Size = new System.Drawing.Size(89, 22);
            this.txtSales.TabIndex = 10;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(787, 57);
            this.txtName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(89, 22);
            this.txtName.TabIndex = 9;
            // 
            // txtStk
            // 
            this.txtStk.Location = new System.Drawing.Point(787, 91);
            this.txtStk.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtStk.Name = "txtStk";
            this.txtStk.Size = new System.Drawing.Size(89, 22);
            this.txtStk.TabIndex = 8;
            // 
            // txtType
            // 
            this.txtType.Location = new System.Drawing.Point(787, 133);
            this.txtType.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(89, 22);
            this.txtType.TabIndex = 7;
            // 
            // listViewDrinks
            // 
            this.listViewDrinks.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.drinkid,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8});
            this.listViewDrinks.FullRowSelect = true;
            this.listViewDrinks.HideSelection = false;
            this.listViewDrinks.Location = new System.Drawing.Point(21, 52);
            this.listViewDrinks.Margin = new System.Windows.Forms.Padding(4);
            this.listViewDrinks.Name = "listViewDrinks";
            this.listViewDrinks.Size = new System.Drawing.Size(640, 377);
            this.listViewDrinks.TabIndex = 5;
            this.listViewDrinks.UseCompatibleStateImageBehavior = false;
            this.listViewDrinks.View = System.Windows.Forms.View.Details;
            // 
            // drinkid
            // 
            this.drinkid.Text = "DrinkID";
            this.drinkid.Width = 100;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "stock";
            this.columnHeader5.Width = 100;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Names";
            this.columnHeader6.Width = 100;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Sales_price";
            this.columnHeader7.Width = 100;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Drink_type";
            this.columnHeader8.Width = 100;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox4.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.InitialImage")));
            this.pictureBox4.Location = new System.Drawing.Point(963, 2);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(173, 151);
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // lblDrink
            // 
            this.lblDrink.AutoSize = true;
            this.lblDrink.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDrink.Location = new System.Drawing.Point(13, 12);
            this.lblDrink.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDrink.Name = "lblDrink";
            this.lblDrink.Size = new System.Drawing.Size(219, 33);
            this.lblDrink.TabIndex = 3;
            this.lblDrink.Text = "Drinks Supplies";
            // 
            // pnlCRegister
            // 
            this.pnlCRegister.Controls.Add(this.lblTotalprice);
            this.pnlCRegister.Controls.Add(this.lblStudent);
            this.pnlCRegister.Controls.Add(this.label4);
            this.pnlCRegister.Controls.Add(this.label3);
            this.pnlCRegister.Controls.Add(this.btnCheckout);
            this.pnlCRegister.Controls.Add(this.lvCDrink);
            this.pnlCRegister.Controls.Add(this.lvCStudent);
            this.pnlCRegister.Controls.Add(this.label8);
            this.pnlCRegister.Controls.Add(this.pictureBox5);
            this.pnlCRegister.Controls.Add(this.label9);
            this.pnlCRegister.Location = new System.Drawing.Point(0, 42);
            this.pnlCRegister.Margin = new System.Windows.Forms.Padding(4);
            this.pnlCRegister.Name = "pnlCRegister";
            this.pnlCRegister.Size = new System.Drawing.Size(1251, 574);
            this.pnlCRegister.TabIndex = 21;
            // 
            // lblTotalprice
            // 
            this.lblTotalprice.AutoSize = true;
            this.lblTotalprice.Location = new System.Drawing.Point(744, 153);
            this.lblTotalprice.Name = "lblTotalprice";
            this.lblTotalprice.Size = new System.Drawing.Size(24, 17);
            this.lblTotalprice.TabIndex = 18;
            this.lblTotalprice.Text = "....";
            // 
            // lblStudent
            // 
            this.lblStudent.AutoSize = true;
            this.lblStudent.Location = new System.Drawing.Point(744, 86);
            this.lblStudent.Name = "lblStudent";
            this.lblStudent.Size = new System.Drawing.Size(24, 17);
            this.lblStudent.TabIndex = 17;
            this.lblStudent.Text = "....";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(677, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 17);
            this.label4.TabIndex = 16;
            this.label4.Text = "Total:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(677, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 17);
            this.label3.TabIndex = 15;
            this.label3.Text = "Student:";
            // 
            // btnCheckout
            // 
            this.btnCheckout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnCheckout.Location = new System.Drawing.Point(680, 210);
            this.btnCheckout.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCheckout.Name = "btnCheckout";
            this.btnCheckout.Size = new System.Drawing.Size(188, 71);
            this.btnCheckout.TabIndex = 14;
            this.btnCheckout.Text = "&Checkout";
            this.btnCheckout.UseVisualStyleBackColor = true;
            this.btnCheckout.Click += new System.EventHandler(this.btnCheckout_Click);
            // 
            // lvCDrink
            // 
            this.lvCDrink.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Drink,
            this.columnHeader10,
            this.columnHeader11});
            this.lvCDrink.FullRowSelect = true;
            this.lvCDrink.HideSelection = false;
            this.lvCDrink.Location = new System.Drawing.Point(251, 73);
            this.lvCDrink.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lvCDrink.Name = "lvCDrink";
            this.lvCDrink.Scrollable = false;
            this.lvCDrink.Size = new System.Drawing.Size(367, 377);
            this.lvCDrink.TabIndex = 13;
            this.lvCDrink.UseCompatibleStateImageBehavior = false;
            this.lvCDrink.View = System.Windows.Forms.View.Details;
            this.lvCDrink.SelectedIndexChanged += new System.EventHandler(this.lvCDrink_SelectedIndexChanged);
            // 
            // Drink
            // 
            this.Drink.Text = "Drink";
            this.Drink.Width = 131;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Price";
            this.columnHeader10.Width = 103;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Stock";
            this.columnHeader11.Width = 122;
            // 
            // lvCStudent
            // 
            this.lvCStudent.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4});
            this.lvCStudent.FullRowSelect = true;
            this.lvCStudent.HideSelection = false;
            this.lvCStudent.Location = new System.Drawing.Point(21, 73);
            this.lvCStudent.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lvCStudent.MultiSelect = false;
            this.lvCStudent.Name = "lvCStudent";
            this.lvCStudent.Scrollable = false;
            this.lvCStudent.Size = new System.Drawing.Size(223, 377);
            this.lvCStudent.TabIndex = 12;
            this.lvCStudent.UseCompatibleStateImageBehavior = false;
            this.lvCStudent.View = System.Windows.Forms.View.Details;
            this.lvCStudent.SelectedIndexChanged += new System.EventHandler(this.lvCStudent_SelectedIndexChanged);
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Students";
            this.columnHeader4.Width = 169;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(569, 54);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 17);
            this.label8.TabIndex = 11;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox5.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.InitialImage")));
            this.pictureBox5.Location = new System.Drawing.Point(1056, 2);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(173, 151);
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(13, 12);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(200, 33);
            this.label9.TabIndex = 3;
            this.label9.Text = "Cash Register";
            // 
            // pnlRevenueReport
            // 
            this.pnlRevenueReport.Controls.Add(this.labelErrorFounder);
            this.pnlRevenueReport.Controls.Add(this.label7);
            this.pnlRevenueReport.Controls.Add(this.label6);
            this.pnlRevenueReport.Controls.Add(this.label5);
            this.pnlRevenueReport.Controls.Add(this.btnReport);
            this.pnlRevenueReport.Controls.Add(this.labelNumOfCustomers);
            this.pnlRevenueReport.Controls.Add(this.labelTurnOver);
            this.pnlRevenueReport.Controls.Add(this.labelSales);
            this.pnlRevenueReport.Controls.Add(this.dateTimePickerEndDate);
            this.pnlRevenueReport.Controls.Add(this.dateTimePickerStartDate);
            this.pnlRevenueReport.Controls.Add(this.lblEndDate);
            this.pnlRevenueReport.Controls.Add(this.lblStartDate);
            this.pnlRevenueReport.Controls.Add(this.pictureBox9);
            this.pnlRevenueReport.Controls.Add(this.label26);
            this.pnlRevenueReport.Location = new System.Drawing.Point(0, 42);
            this.pnlRevenueReport.Margin = new System.Windows.Forms.Padding(4);
            this.pnlRevenueReport.Name = "pnlRevenueReport";
            this.pnlRevenueReport.Size = new System.Drawing.Size(1251, 574);
            this.pnlRevenueReport.TabIndex = 22;
            // 
            // labelErrorFounder
            // 
            this.labelErrorFounder.AutoSize = true;
            this.labelErrorFounder.ForeColor = System.Drawing.Color.Red;
            this.labelErrorFounder.Location = new System.Drawing.Point(16, 190);
            this.labelErrorFounder.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelErrorFounder.Name = "labelErrorFounder";
            this.labelErrorFounder.Size = new System.Drawing.Size(101, 17);
            this.labelErrorFounder.TabIndex = 15;
            this.labelErrorFounder.Text = "Error Founder.";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(563, 234);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 17);
            this.label7.TabIndex = 14;
            this.label7.Text = "Sales:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(563, 149);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 17);
            this.label6.TabIndex = 13;
            this.label6.Text = "TurnOver:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(563, 86);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(152, 17);
            this.label5.TabIndex = 12;
            this.label5.Text = "Number Of Customers:";
            // 
            // btnReport
            // 
            this.btnReport.Location = new System.Drawing.Point(19, 228);
            this.btnReport.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(109, 28);
            this.btnReport.TabIndex = 11;
            this.btnReport.Text = "CheckOut";
            this.btnReport.UseVisualStyleBackColor = true;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // labelNumOfCustomers
            // 
            this.labelNumOfCustomers.AutoSize = true;
            this.labelNumOfCustomers.Location = new System.Drawing.Point(749, 86);
            this.labelNumOfCustomers.Name = "labelNumOfCustomers";
            this.labelNumOfCustomers.Size = new System.Drawing.Size(20, 17);
            this.labelNumOfCustomers.TabIndex = 10;
            this.labelNumOfCustomers.Text = "...";
            this.labelNumOfCustomers.Click += new System.EventHandler(this.labelNumOfCustomers_Click);
            // 
            // labelTurnOver
            // 
            this.labelTurnOver.AutoSize = true;
            this.labelTurnOver.Location = new System.Drawing.Point(749, 148);
            this.labelTurnOver.Name = "labelTurnOver";
            this.labelTurnOver.Size = new System.Drawing.Size(20, 17);
            this.labelTurnOver.TabIndex = 9;
            this.labelTurnOver.Text = "...";
            // 
            // labelSales
            // 
            this.labelSales.AutoSize = true;
            this.labelSales.Location = new System.Drawing.Point(749, 234);
            this.labelSales.Name = "labelSales";
            this.labelSales.Size = new System.Drawing.Size(20, 17);
            this.labelSales.TabIndex = 8;
            this.labelSales.Text = "...";
            // 
            // dateTimePickerEndDate
            // 
            this.dateTimePickerEndDate.Location = new System.Drawing.Point(284, 98);
            this.dateTimePickerEndDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateTimePickerEndDate.Name = "dateTimePickerEndDate";
            this.dateTimePickerEndDate.Size = new System.Drawing.Size(212, 22);
            this.dateTimePickerEndDate.TabIndex = 7;
            this.dateTimePickerEndDate.ValueChanged += new System.EventHandler(this.dateTimePickerEndDate_ValueChanged);
            // 
            // dateTimePickerStartDate
            // 
            this.dateTimePickerStartDate.Location = new System.Drawing.Point(19, 98);
            this.dateTimePickerStartDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateTimePickerStartDate.Name = "dateTimePickerStartDate";
            this.dateTimePickerStartDate.Size = new System.Drawing.Size(212, 22);
            this.dateTimePickerStartDate.TabIndex = 6;
            this.dateTimePickerStartDate.ValueChanged += new System.EventHandler(this.dateTimePickerStartDate_ValueChanged);
            // 
            // lblEndDate
            // 
            this.lblEndDate.AutoSize = true;
            this.lblEndDate.Location = new System.Drawing.Point(281, 66);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(67, 17);
            this.lblEndDate.TabIndex = 5;
            this.lblEndDate.Text = "End Date";
            this.lblEndDate.Click += new System.EventHandler(this.label22_Click);
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Location = new System.Drawing.Point(16, 66);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(72, 17);
            this.lblStartDate.TabIndex = 4;
            this.lblStartDate.Text = "Start Date";
            this.lblStartDate.Click += new System.EventHandler(this.label21_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox9.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox9.InitialImage")));
            this.pictureBox9.Location = new System.Drawing.Point(1056, 2);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(173, 151);
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(13, 12);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(226, 33);
            this.label26.TabIndex = 3;
            this.label26.Text = "Revenue Report";
            // 
            // pnlAS
            // 
            this.pnlAS.Controls.Add(this.cmbTeacher);
            this.pnlAS.Controls.Add(this.cmbActivities);
            this.pnlAS.Controls.Add(this.label21);
            this.pnlAS.Controls.Add(this.lblActivity);
            this.pnlAS.Controls.Add(this.btnRemoveSupervisor);
            this.pnlAS.Controls.Add(this.btnAddSupervisor);
            this.pnlAS.Controls.Add(this.label18);
            this.pnlAS.Controls.Add(this.label19);
            this.pnlAS.Controls.Add(this.lvSupervisorActivities);
            this.pnlAS.Controls.Add(this.pictureBox6);
            this.pnlAS.Controls.Add(this.label20);
            this.pnlAS.Location = new System.Drawing.Point(0, 42);
            this.pnlAS.Margin = new System.Windows.Forms.Padding(4);
            this.pnlAS.Name = "pnlAS";
            this.pnlAS.Size = new System.Drawing.Size(1261, 579);
            this.pnlAS.TabIndex = 36;
            // 
            // cmbTeacher
            // 
            this.cmbTeacher.FormattingEnabled = true;
            this.cmbTeacher.Location = new System.Drawing.Point(768, 142);
            this.cmbTeacher.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbTeacher.Name = "cmbTeacher";
            this.cmbTeacher.Size = new System.Drawing.Size(172, 24);
            this.cmbTeacher.TabIndex = 38;
            // 
            // cmbActivities
            // 
            this.cmbActivities.FormattingEnabled = true;
            this.cmbActivities.Location = new System.Drawing.Point(52, 121);
            this.cmbActivities.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbActivities.Name = "cmbActivities";
            this.cmbActivities.Size = new System.Drawing.Size(172, 24);
            this.cmbActivities.TabIndex = 37;
            this.cmbActivities.SelectedIndexChanged += new System.EventHandler(this.cmbActivities_SelectedIndexChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(765, 107);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(111, 17);
            this.label21.TabIndex = 36;
            this.label21.Text = "Select a teacher";
            // 
            // lblActivity
            // 
            this.lblActivity.AutoSize = true;
            this.lblActivity.Location = new System.Drawing.Point(773, 192);
            this.lblActivity.Name = "lblActivity";
            this.lblActivity.Size = new System.Drawing.Size(20, 17);
            this.lblActivity.TabIndex = 33;
            this.lblActivity.Text = "...";
            // 
            // btnRemoveSupervisor
            // 
            this.btnRemoveSupervisor.Location = new System.Drawing.Point(768, 330);
            this.btnRemoveSupervisor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRemoveSupervisor.Name = "btnRemoveSupervisor";
            this.btnRemoveSupervisor.Size = new System.Drawing.Size(115, 34);
            this.btnRemoveSupervisor.TabIndex = 31;
            this.btnRemoveSupervisor.Text = "&Remove";
            this.btnRemoveSupervisor.UseVisualStyleBackColor = true;
            this.btnRemoveSupervisor.Click += new System.EventHandler(this.btnRemoveSupervisor_Click);
            // 
            // btnAddSupervisor
            // 
            this.btnAddSupervisor.Location = new System.Drawing.Point(768, 256);
            this.btnAddSupervisor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAddSupervisor.Name = "btnAddSupervisor";
            this.btnAddSupervisor.Size = new System.Drawing.Size(115, 34);
            this.btnAddSupervisor.TabIndex = 29;
            this.btnAddSupervisor.Text = "&Add";
            this.btnAddSupervisor.UseVisualStyleBackColor = true;
            this.btnAddSupervisor.Click += new System.EventHandler(this.btnAddSupervisor_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(77, 82);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(114, 17);
            this.label18.TabIndex = 26;
            this.label18.Text = "Select an activity";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(659, 164);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(0, 17);
            this.label19.TabIndex = 25;
            // 
            // lvSupervisorActivities
            // 
            this.lvSupervisorActivities.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader15,
            this.columnHeader16});
            this.lvSupervisorActivities.FullRowSelect = true;
            this.lvSupervisorActivities.HideSelection = false;
            this.lvSupervisorActivities.Location = new System.Drawing.Point(316, 52);
            this.lvSupervisorActivities.Margin = new System.Windows.Forms.Padding(4);
            this.lvSupervisorActivities.Name = "lvSupervisorActivities";
            this.lvSupervisorActivities.Size = new System.Drawing.Size(400, 377);
            this.lvSupervisorActivities.TabIndex = 5;
            this.lvSupervisorActivities.UseCompatibleStateImageBehavior = false;
            this.lvSupervisorActivities.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Supervisor";
            this.columnHeader15.Width = 150;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Activity";
            this.columnHeader16.Width = 150;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox6.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.InitialImage")));
            this.pictureBox6.Location = new System.Drawing.Point(1075, 0);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(173, 151);
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(28, 12);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(334, 33);
            this.label20.TabIndex = 3;
            this.label20.Text = "Supervisors for activities";
            // 
            // pnlParticipants
            // 
            this.pnlParticipants.Controls.Add(this.cmbStudents);
            this.pnlParticipants.Controls.Add(this.cmbParticipantsOfActivities);
            this.pnlParticipants.Controls.Add(this.label10);
            this.pnlParticipants.Controls.Add(this.lblParticipant);
            this.pnlParticipants.Controls.Add(this.btnRemoveParticipant);
            this.pnlParticipants.Controls.Add(this.btnAddParticipant);
            this.pnlParticipants.Controls.Add(this.label17);
            this.pnlParticipants.Controls.Add(this.label22);
            this.pnlParticipants.Controls.Add(this.lvParticipantActivities);
            this.pnlParticipants.Controls.Add(this.pictureBox8);
            this.pnlParticipants.Controls.Add(this.label23);
            this.pnlParticipants.Location = new System.Drawing.Point(0, 42);
            this.pnlParticipants.Margin = new System.Windows.Forms.Padding(4);
            this.pnlParticipants.Name = "pnlParticipants";
            this.pnlParticipants.Size = new System.Drawing.Size(1261, 578);
            this.pnlParticipants.TabIndex = 37;
            // 
            // cmbStudents
            // 
            this.cmbStudents.FormattingEnabled = true;
            this.cmbStudents.Location = new System.Drawing.Point(768, 142);
            this.cmbStudents.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbStudents.Name = "cmbStudents";
            this.cmbStudents.Size = new System.Drawing.Size(172, 24);
            this.cmbStudents.TabIndex = 38;
            // 
            // cmbParticipantsOfActivities
            // 
            this.cmbParticipantsOfActivities.FormattingEnabled = true;
            this.cmbParticipantsOfActivities.Location = new System.Drawing.Point(52, 121);
            this.cmbParticipantsOfActivities.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbParticipantsOfActivities.Name = "cmbParticipantsOfActivities";
            this.cmbParticipantsOfActivities.Size = new System.Drawing.Size(172, 24);
            this.cmbParticipantsOfActivities.TabIndex = 37;
            this.cmbParticipantsOfActivities.SelectedIndexChanged += new System.EventHandler(this.cmbParticipantsOfActivities_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(765, 107);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(112, 17);
            this.label10.TabIndex = 36;
            this.label10.Text = "Select a Student";
            // 
            // lblParticipant
            // 
            this.lblParticipant.AutoSize = true;
            this.lblParticipant.Location = new System.Drawing.Point(773, 192);
            this.lblParticipant.Name = "lblParticipant";
            this.lblParticipant.Size = new System.Drawing.Size(20, 17);
            this.lblParticipant.TabIndex = 33;
            this.lblParticipant.Text = "...";
            // 
            // btnRemoveParticipant
            // 
            this.btnRemoveParticipant.Location = new System.Drawing.Point(768, 330);
            this.btnRemoveParticipant.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRemoveParticipant.Name = "btnRemoveParticipant";
            this.btnRemoveParticipant.Size = new System.Drawing.Size(115, 34);
            this.btnRemoveParticipant.TabIndex = 31;
            this.btnRemoveParticipant.Text = "&Remove";
            this.btnRemoveParticipant.UseVisualStyleBackColor = true;
            this.btnRemoveParticipant.Click += new System.EventHandler(this.btnRemoveParticipant_Click);
            // 
            // btnAddParticipant
            // 
            this.btnAddParticipant.Location = new System.Drawing.Point(768, 256);
            this.btnAddParticipant.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAddParticipant.Name = "btnAddParticipant";
            this.btnAddParticipant.Size = new System.Drawing.Size(115, 34);
            this.btnAddParticipant.TabIndex = 29;
            this.btnAddParticipant.Text = "&Add";
            this.btnAddParticipant.UseVisualStyleBackColor = true;
            this.btnAddParticipant.Click += new System.EventHandler(this.btnAddParticipant_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(77, 82);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(116, 17);
            this.label17.TabIndex = 26;
            this.label17.Text = "Select An Activity";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(659, 164);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(0, 17);
            this.label22.TabIndex = 25;
            // 
            // lvParticipantActivities
            // 
            this.lvParticipantActivities.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader17,
            this.columnHeader18});
            this.lvParticipantActivities.FullRowSelect = true;
            this.lvParticipantActivities.HideSelection = false;
            this.lvParticipantActivities.Location = new System.Drawing.Point(329, 52);
            this.lvParticipantActivities.Margin = new System.Windows.Forms.Padding(4);
            this.lvParticipantActivities.Name = "lvParticipantActivities";
            this.lvParticipantActivities.Size = new System.Drawing.Size(405, 377);
            this.lvParticipantActivities.TabIndex = 5;
            this.lvParticipantActivities.UseCompatibleStateImageBehavior = false;
            this.lvParticipantActivities.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "Participants";
            this.columnHeader17.Width = 150;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "Activity";
            this.columnHeader18.Width = 150;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox8.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox8.InitialImage")));
            this.pictureBox8.Location = new System.Drawing.Point(1075, 0);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(173, 151);
            this.pictureBox8.TabIndex = 0;
            this.pictureBox8.TabStop = false;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(28, 12);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(332, 33);
            this.label23.TabIndex = 3;
            this.label23.Text = "Participants Of Activities";
            // 
            // SomerenUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1750, 870);
            this.Controls.Add(this.pnlDashboard);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.pnlStudents);
            this.Controls.Add(this.pnlTeacher);
            this.Controls.Add(this.pnlActivity);
            this.Controls.Add(this.pnlRoom);
            this.Controls.Add(this.pnlDrinks);
            this.Controls.Add(this.pnlCRegister);
            this.Controls.Add(this.pnlRevenueReport);
            this.Controls.Add(this.pnlAS);
            this.Controls.Add(this.pnlParticipants);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "SomerenUI";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "SomerenApp";
            this.Load += new System.EventHandler(this.SomerenUI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.imgDashboard)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.pnlDashboard.ResumeLayout(false);
            this.pnlDashboard.PerformLayout();
            this.pnlActivity.ResumeLayout(false);
            this.pnlActivity.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.pnlStudents.ResumeLayout(false);
            this.pnlStudents.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlTeacher.ResumeLayout(false);
            this.pnlTeacher.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.pnlRoom.ResumeLayout(false);
            this.pnlRoom.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.pnlDrinks.ResumeLayout(false);
            this.pnlDrinks.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.pnlCRegister.ResumeLayout(false);
            this.pnlCRegister.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.pnlRevenueReport.ResumeLayout(false);
            this.pnlRevenueReport.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.pnlAS.ResumeLayout(false);
            this.pnlAS.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.pnlParticipants.ResumeLayout(false);
            this.pnlParticipants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox imgDashboard;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dashboardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dashboardToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Panel pnlDashboard;
        private System.Windows.Forms.Label lbl_Dashboard;
        private System.Windows.Forms.ToolStripMenuItem studentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lecturersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem activitiesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem roomsToolStripMenuItem;
        private System.Windows.Forms.Panel pnlStudents;
        private System.Windows.Forms.Label lbl_Students;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ListView listViewStudents;
        private System.Windows.Forms.ColumnHeader studentID;
        private System.Windows.Forms.ColumnHeader studentName;
        private System.Windows.Forms.ColumnHeader studentDOB;
        private System.Windows.Forms.Panel pnlTeacher;
        private System.Windows.Forms.ListView listViewTeacher;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lbl_Teacher;
        private System.Windows.Forms.ColumnHeader TeacherID;
        private System.Windows.Forms.ColumnHeader RoomID;
        private System.Windows.Forms.ColumnHeader firstname;
        private System.Windows.Forms.ColumnHeader lastname;
        private System.Windows.Forms.ColumnHeader supervisor;
        private System.Windows.Forms.Panel pnlRoom;
        private System.Windows.Forms.ListView listViewRoom;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem drinksSuppliesToolStripMenuItem;
        private System.Windows.Forms.Panel pnlDrinks;
        private System.Windows.Forms.ListView listViewDrinks;
        private System.Windows.Forms.ColumnHeader drinkid;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label lblDrink;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnChange;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Label lblStock;
        private System.Windows.Forms.Label lblNames;
        private System.Windows.Forms.Label lblSales;
        private System.Windows.Forms.Label lblDrinkID;
        private System.Windows.Forms.TextBox txtSales;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtStk;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.TextBox txtDrinkID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem cashRegisterToolStripMenuItem;
        private System.Windows.Forms.Panel pnlCRegister;
        private System.Windows.Forms.Label lblTotalprice;
        private System.Windows.Forms.Label lblStudent;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCheckout;
        private System.Windows.Forms.ListView lvCDrink;
        private System.Windows.Forms.ColumnHeader Drink;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ListView lvCStudent;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel pnlRevenueReport;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.DateTimePicker dateTimePickerEndDate;
        private System.Windows.Forms.DateTimePicker dateTimePickerStartDate;
        private System.Windows.Forms.ToolStripMenuItem revenueReportToolStripMenuItem;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.Label labelNumOfCustomers;
        private System.Windows.Forms.Label labelTurnOver;
        private System.Windows.Forms.Label labelSales;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelErrorFounder;
        private System.Windows.Forms.Panel pnlActivity;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtActivityid;
        private System.Windows.Forms.Button butremove;
        private System.Windows.Forms.Button butchange;
        private System.Windows.Forms.Button butadd;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label txtnameacti;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtnameactivity;
        private System.Windows.Forms.ListView listViewActivity;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dateEnd;
        private System.Windows.Forms.DateTimePicker dateStart;
        private System.Windows.Forms.Panel pnlAS;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lblActivity;
        private System.Windows.Forms.Button btnRemoveSupervisor;
        private System.Windows.Forms.Button btnAddSupervisor;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ListView lvSupervisorActivities;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox cmbTeacher;
        private System.Windows.Forms.ComboBox cmbActivities;
        private System.Windows.Forms.ToolStripMenuItem supervisorToolStripMenuItem;
        private System.Windows.Forms.Panel pnlParticipants;
        private System.Windows.Forms.ComboBox cmbStudents;
        private System.Windows.Forms.ComboBox cmbParticipantsOfActivities;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblParticipant;
        private System.Windows.Forms.Button btnRemoveParticipant;
        private System.Windows.Forms.Button btnAddParticipant;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ListView lvParticipantActivities;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ToolStripMenuItem participantsToolStripMenuItem;
    }
}

