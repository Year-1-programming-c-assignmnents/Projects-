﻿
namespace SomerenUI
{
    partial class ForgotPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.lblPassWord = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.txtQuestionAns = new System.Windows.Forms.TextBox();
            this.lblSecretquestion = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNewPassword = new System.Windows.Forms.TextBox();
            this.btnCheck = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnFPBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(323, 40);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(140, 22);
            this.txtUsername.TabIndex = 7;
            this.txtUsername.TextChanged += new System.EventHandler(this.txtUsername_TextChanged);
            // 
            // lblPassWord
            // 
            this.lblPassWord.AutoSize = true;
            this.lblPassWord.Location = new System.Drawing.Point(171, 97);
            this.lblPassWord.Name = "lblPassWord";
            this.lblPassWord.Size = new System.Drawing.Size(99, 17);
            this.lblPassWord.TabIndex = 6;
            this.lblPassWord.Text = "Secret Answer";
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Location = new System.Drawing.Point(205, 43);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(73, 17);
            this.lblUsername.TabIndex = 5;
            this.lblUsername.Text = "Username";
            // 
            // txtQuestionAns
            // 
            this.txtQuestionAns.Location = new System.Drawing.Point(323, 97);
            this.txtQuestionAns.Name = "txtQuestionAns";
            this.txtQuestionAns.Size = new System.Drawing.Size(140, 22);
            this.txtQuestionAns.TabIndex = 9;
            this.txtQuestionAns.TextChanged += new System.EventHandler(this.txtQuestionAns_TextChanged);
            // 
            // lblSecretquestion
            // 
            this.lblSecretquestion.AutoSize = true;
            this.lblSecretquestion.Location = new System.Drawing.Point(320, 97);
            this.lblSecretquestion.Name = "lblSecretquestion";
            this.lblSecretquestion.Size = new System.Drawing.Size(0, 17);
            this.lblSecretquestion.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(171, 213);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 17);
            this.label1.TabIndex = 10;
            this.label1.Text = "New password";
            // 
            // txtNewPassword
            // 
            this.txtNewPassword.Location = new System.Drawing.Point(323, 213);
            this.txtNewPassword.Name = "txtNewPassword";
            this.txtNewPassword.Size = new System.Drawing.Size(140, 22);
            this.txtNewPassword.TabIndex = 11;
            this.txtNewPassword.TextChanged += new System.EventHandler(this.txtNewPassword_TextChanged);
            // 
            // btnCheck
            // 
            this.btnCheck.Location = new System.Drawing.Point(388, 137);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(75, 26);
            this.btnCheck.TabIndex = 12;
            this.btnCheck.Text = "&Check";
            this.btnCheck.UseVisualStyleBackColor = true;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(388, 260);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 26);
            this.btnSubmit.TabIndex = 15;
            this.btnSubmit.Text = "&Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnFPBack
            // 
            this.btnFPBack.Location = new System.Drawing.Point(24, 291);
            this.btnFPBack.Name = "btnFPBack";
            this.btnFPBack.Size = new System.Drawing.Size(75, 26);
            this.btnFPBack.TabIndex = 16;
            this.btnFPBack.Text = "Back";
            this.btnFPBack.UseVisualStyleBackColor = true;
            this.btnFPBack.Click += new System.EventHandler(this.btnFPBack_Click);
            // 
            // ForgotPassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(688, 343);
            this.Controls.Add(this.btnFPBack);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.txtNewPassword);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtQuestionAns);
            this.Controls.Add(this.lblSecretquestion);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.lblPassWord);
            this.Controls.Add(this.lblUsername);
            this.Name = "ForgotPassword";
            this.Text = "ForgotPassword";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label lblPassWord;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.TextBox txtQuestionAns;
        private System.Windows.Forms.Label lblSecretquestion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNewPassword;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnFPBack;
    }
}