﻿using SomerenLogic;
using SomerenModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SomerenUI
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            string RegistrationKey = "XsZAb - tgz3PsD - qYh69un - WQCEx";
            Users createaccount = new Users();
            createaccount.UserName = txtUsername.Text;
            createaccount.UserPassword = txtPassWord.Text;
            if(txtRegistrationKey.Text == RegistrationKey)
            {
                UsersService usersService = new UsersService();
                usersService.AddToListUsers(createaccount);
                MessageBox.Show("Welcome to Someren Application! Account Successfully Created!");
                ShowLoginForm();
            }
            else
            {
                MessageBox.Show("Please check your Registration Key!");
            }
        }
        private void ShowLoginForm ()
        {
            this.Hide();
            Login login = new Login();
            login.Show();
        }

        private void btnSignUpBack_Click(object sender, EventArgs e)
        {
            ShowLoginForm();
        }
    }
}
